create view ZCRM_R005 as
  SELECT "会员ID","销售金额","订单日期","月","分类","区域",FOPOR
FROM
(
    SELECT ord.cardno as 会员ID,ord.SYSCOST as 销售金额,substr(ord.EXITDATE,1,4)||'-'||substr(ord.EXITDATE,5,2) AS 订单日期,
           substr(ord.EXITDATE,5,2) AS 月,ord.FOPOR,
           FUN_SPLIT_ONE(d.FPROPERTY_VALUE,'/',6) AS 分类 ,(SUBSTR(B.FA003_NAME,0,2)||B.FA002_NAME) AS 区域
            --B.FA002_NAME as 区域,SUBSTR(B.FA003_NAME,0,2) as 门店类型
    FROM 
        ZBW_POSSALES_CRM_MAIN ord  
        LEFT JOIN BN_BIZ_SKU d on ord.ITEMCODE = d.FCODE 
        LEFT JOIN BN_SYS_ORG_INFO B ON ord.SHPCODE = B.FPCODE
) where --(分类 = '非黄' OR 分类 = '黄金') 
 (区域 LIKE '加盟%' OR 区域 LIKE '直营%' OR 区域 LIKE 'da%') and "销售金额" <> '0' and FOPOR NOT like '%内购%'
/

