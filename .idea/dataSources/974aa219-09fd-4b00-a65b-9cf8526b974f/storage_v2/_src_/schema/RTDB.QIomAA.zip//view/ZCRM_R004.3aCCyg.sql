create view ZCRM_R004 as
  select to_char("card_giving_time",'yyyymm') as 年月,b.FA002_NAME as 销售地区,"store_code" as 门店代码,b.FA030_NAME as 区域经理,"wx_member" as 微信,count("card_num") as 开卡人数 
from crm_tab_gic_member a left join BN_SYS_ORG_INFO b on a."store_code"=b.FCODE
where "card_num" <> -1 and "store_code" not in('saler_E3','5274','5271')
group by to_char("card_giving_time",'yyyymm'),b.FA002_NAME,"store_code",b.FA030_NAME,"wx_member"
/

