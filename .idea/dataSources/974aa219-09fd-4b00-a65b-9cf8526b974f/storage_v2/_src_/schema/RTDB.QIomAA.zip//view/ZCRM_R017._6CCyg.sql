create view ZCRM_R017 as
  SELECT
a."card_num" as 卡号,
b.EXITDATE as 消费时间,
a."card_giving_time" as 开卡时间,
a."store_code" as 门店代码,
c. "FA002_NAME" AS 区域,
"TO_CHAR"(a."card_giving_time",'yyyy-mm') as 开卡年月,
"TO_CHAR"(a."card_giving_time",'mm') as 开卡月
from crm_tab_gic_member a 
LEFT JOIN ZBW_POSSALES_CRM_MAIN  b on a."card_num" = b.cardno
LEFT JOIN BN_SYS_ORG_INFO c on a."store_code" = c."FCODE"
where "card_num" <> '-1' and  a."store_code" <> 'saler_E3' and a."store_code" <> '5274'  and a."store_code" <> '5271' and a."store_code" <> '1111'
/

