create package body ETL_CRM_DATA is
 VMSG    VARCHAR2(255);
 

 PROCEDURE ETL_PAC_STORE(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_store where to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 insert into  CRM_TAB_GIC_store select * from "tab_gic_store"@mysql  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_store  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd'); 
        
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_STORE', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_store', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
     
 end;
 --***************************************************************
  PROCEDURE ETL_PAC_CLERK(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_CLERK where to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 insert into  CRM_TAB_GIC_CLERK select * from "tab_gic_clerk"@mysql  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_CLERK  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd'); 
        
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_CLERK', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_CLERK', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
     
 end;
--***************************************************************************
 PROCEDURE  ETL_PAC_COUP_CARD(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_COUP_CARD where to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');

insert into CRM_TAB_GIC_COUP_CARD("coup_card_id", 
  "enterprise_id" , 
  "card_type" , 
  "card_name" , 
  "sub_name" , 
  "sub_title" , 
  "card_color" , 
  "use_condition" , 
  "card_limit" , 
  "card_code_count" , 
  "card_effective_mode" , 
  "begin_date" , 
  "end_date" , 
  "start_day", 
  "limit_day" , 
  "image_field_code" , 
  "image_url", 
  "qcloud_image_url", 
  "cover_descript" , 
  "verification_type" , 
  "create_date" , 
  "update_time" , 
  "auditing_status" , 
  "status" , 
  "member_range" , 
  "coupon_stock" , 
  "issuing_quantity" , 
  "geted_quantity", 
  "usage_quantity", 
  "sale_amount" , 
  "giving_num", 
  "store_mode" , 
  "wechat_card_id" , 
  "card_explain" , 
  "use_custom_code" , 
  "custom_code_begin" , 
  "custom_code_end", 
  "custom_code_prefix" , 
  "custom_code_suffix", 
  "use_code_prefix", 
  "use_code_suffix", 
  "custom_code_sync" , 
  "cost_value", 
  "clique_id" , 
  "channel_type", 
  "applicable_mode" , 
  "applicable_mall_pro_mode" , 
  "applicable_store_pro_mode", 
  "not_applicable_mode" , 
  "not_applicable_mall_pro_mode" , 
  "not_applicable_store_pro_mode" , 
  "calculation_method" , 
  "tag_code", 
  "shelf_type", 
  "shelf_tag_code" , 
  "erp_demo_code" )
 select  "coup_card_id","enterprise_id","card_type" , "card_name","sub_name","sub_title","card_color","card_denomination"
"use_condition","card_limit","card_code_count","card_effective_mode","begin_date","end_date","start_day","limit_day",
"image_field_code","image_url","qcloud_image_url","cover_descript","verification_type","create_date","update_time",
"auditing_status","status","member_range","coupon_stock","issuing_quantity","geted_quantity","usage_quantity","sale_amount",
"giving_num","store_mode","wechat_card_id","card_explain","use_custom_code","custom_code_begin","custom_code_end","custom_code_prefix",
"custom_code_suffix","use_code_prefix","use_code_suffix","custom_code_sync","cost_value","clique_id","channel_type","applicable_mode",
"applicable_mall_pro_mode","applicable_store_pro_mode","not_applicable_mode","not_applicable_mall_pro_mode","not_applicable_store_pro_mode",
"calculation_method","tag_code","shelf_type","shelf_tag_code","erp_demo_code"
from "tab_gic_coup_card"@mysql   where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_COUP_CARD  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd'); 
        
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_COUP_CARD', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_COUP_CARD', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
     
 end;
 --***********************************************
  PROCEDURE ETL_PAC_COUP_CARD_LOG(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_COUP_CARD_LOG where to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 insert into  CRM_TAB_GIC_COUP_CARD_LOG select * from "tab_gic_coup_card_log"@mysql  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_COUP_CARD_LOG  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd'); 
        
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_CLERK', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_COUP_CARD_LOG', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
     
 end;
 --****************************************************
  PROCEDURE ETL_PAC_EVALUATE_MSG_LOG(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_EVALUATE_MSG_LOG where to_char("create_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 insert into  CRM_TAB_GIC_EVALUATE_MSG_LOG select * from "tab_gic_evaluate_msg_log"@mysql  where  to_char("create_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_EVALUATE_MSG_LOG where  to_char("create_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd'); 
        
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_EVALUATE_MSG_LOG', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_EVALUATE_MSG_LOG', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   --no update_time  
 end;
 --**********************************************************
  PROCEDURE ETL_PAC_MEMBER(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_MEMBER where to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 insert into  CRM_TAB_GIC_MEMBER select * from "tab_gic_member"@mysql  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_MEMBER  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd'); 
        
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_MEMBER', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_MEMBER', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
     
 end;
 --***************************************************************
 PROCEDURE ETL_PAC_MEMBER_CLERK(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_MEMBER_CLERK where to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 insert into  CRM_TAB_GIC_MEMBER_CLERK select * from "tab_gic_member_clerk"@mysql  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_MEMBER_CLERK  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd'); 
        
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_MEMBER_CLERK', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_MEMBER_CLERK', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
     
 end;
 --*************************************
 PROCEDURE ETL_PAC_MEMBER_FIELD_VALUE(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_MEMBER_FIELD_VALUE where to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 insert into CRM_TAB_GIC_MEMBER_FIELD_VALUE select * from "tab_gic_member_field_value"@mysql  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_MEMBER_FIELD_VALUE  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd'); 
        
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_MEMBER_FIELD_VALUE', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_MEMBER_FIELD_VALUE', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
--***************************************************************
PROCEDURE ETL_PAC_MEMBER_INFO(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_MEMBER_INFO where to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 insert into CRM_TAB_GIC_MEMBER_INFO select * from "tab_gic_member_info"@mysql  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_MEMBER_INFO  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd'); 
        
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_MEMBER_INFO', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_MEMBER_INFO', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;

PROCEDURE ETL_PAC_MEMBER_INTERVAL_LOG(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM TAB_GIC_MEMBER_INTERVAL_LOG where to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 
 insert into TAB_GIC_MEMBER_INTERVAL_LOG select "interval_log_id" , "member_id" ,"interval_type","interval_remark","interval_history" ,"last_interval" , "effect_time" ,
  "create_time","relation_id" , "orelation_id" ,"store_id" ,"enterprise_id", "interval_inout", "interval_status","interval_effect" ,
  "opt_status" ,"operator_id","update_time" ,"p_member_integral_code", "p_member_integral_name" , "member_integral_code" ,"member_integral_name" 
  "remark" , "frozen_status" ,"unfreeze_time" ,"effect_limit_date" ,"syc_erp_status" , "syc_erp_time","main_store_id" 
  "open_store_id" ,"main_part_store_id" ,"clique_id" ,"clique_member_id"
 from "tab_gic_member_interval_log"@mysql  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 
 select COUNT(*) as rc INTO RECNUM from TAB_GIC_MEMBER_INTERVAL_LOG   where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd'); 
        
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('TAB_GIC_MEMBER_INTERVAL_LOG', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('TAB_GIC_MEMBER_INTERVAL_LOG', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  update_time no ok
 end;
 --************************************************************
 PROCEDURE ETL_PAC_MEMBER_PERSONAL(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_MEMBER_PERSONAL where to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 insert into CRM_TAB_GIC_MEMBER_PERSONAL select * from "tab_gic_member_personal"@mysql  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_MEMBER_PERSONAL  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd'); 
        
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_MEMBER_PERSONAL', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_MEMBER_PERSONAL', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
 
  PROCEDURE ETL_PAC_MEMBER_REMARKS(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_MEMBER_REMARKS where to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 insert into CRM_TAB_GIC_MEMBER_REMARKS select * from "tab_gic_member_remarks"@mysql  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_MEMBER_REMARKS  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd'); 
        
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_MEMBER_REMARKS', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_MEMBER_REMARKS', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
 
  PROCEDURE ETL_PAC_MEMBER_TAGS_RELATION(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM TAB_GIC_MEMBER_TAGS_RELATION where to_char("create_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 insert into TAB_GIC_MEMBER_TAGS_RELATION( select * from "tab_gic_member_tags_relation"@mysql  where  to_char("create_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd'));
 
 select COUNT(*) as rc INTO RECNUM from TAB_GIC_MEMBER_TAGS_RELATION  where  to_char("create_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd'); 
        
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('TAB_GIC_MEMBER_TAGS_RELATION', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('TAB_GIC_MEMBER_TAGS_RELATION', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
 
  PROCEDURE ETL_PAC_TAGS(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_TAGS where to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 insert into CRM_TAB_GIC_TAGS select * from "tab_gic_tags"@mysql  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_TAGS  where  to_char("update_time",'yyyymmdd')=to_char(PIDATE,'yyyymmdd'); 
        
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_TAGS', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_TAGS', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
 
  PROCEDURE ETL_PAC_ERP_ORDER(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM POS_TAB_ERP_ORDER where to_char("UpdateTime",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 insert into POS_TAB_ERP_ORDER select  "CardNo","StoreCode","StoreName","FacoryCode","SalerCode","SalerName","Clerkcode","OrderStatus","OrderTime","ReceiptsTime","OrderSerial",
"OorderSerial","RorderSerial","PPrice","APrice","RPayInfo","RPrice","RebatePrice","CouponCode","Remark","CreateTime","UpdateTime","Status" 
 from "TAB_ERP_ORDER"@mssql  where  to_char("UpdateTime",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 
 select COUNT(*) as rc INTO RECNUM from POS_TAB_ERP_ORDER   where  to_char("UpdateTime",'yyyymmdd')=to_char(PIDATE,'yyyymmdd'); 
        
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('POS_TAB_ERP_ORDER', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('POS_TAB_ERP_ORDER', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
 
---*****************************************
PROCEDURE ETL_PAC_ERP_ORDER_ITEM(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM POS_TAB_ERP_ORDER_ITEM where to_char("Createtime",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 insert into POS_TAB_ERP_ORDER_ITEM select * from "TAB_ERP_ORDER_ITEM"@mssql  where  to_char("Createtime",'yyyymmdd')=to_char(PIDATE,'yyyymmdd');
 
 select COUNT(*) as rc INTO RECNUM from POS_TAB_ERP_ORDER_ITEM  where  to_char("Createtime",'yyyymmdd')=to_char(PIDATE,'yyyymmdd'); 
        
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('POS_TAB_ERP_ORDER_ITEM', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('POS_TAB_ERP_ORDER_ITEM', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
 
 PROCEDURE ETL_PAC_TOTAL AS 
 PIDATE date;  
 BEGIN
  PIDATE := TRUNC(SYSDATE-1);
  ETL_PAC_STORE(PIDATE  );
  ETL_PAC_CLERK(PIDATE  );
  ETL_PAC_COUP_CARD(PIDATE );
  ETL_PAC_COUP_CARD_LOG(PIDATE );
  ETL_PAC_EVALUATE_MSG_LOG(PIDATE );
  ETL_PAC_MEMBER(PIDATE );
  ETL_PAC_MEMBER_CLERK(PIDATE );
  ETL_PAC_MEMBER_FIELD_VALUE(PIDATE );
  ETL_PAC_MEMBER_INFO(PIDATE );
  ETL_PAC_MEMBER_INTERVAL_LOG(PIDATE );
  ETL_PAC_MEMBER_PERSONAL(PIDATE );
  ETL_PAC_MEMBER_REMARKS(PIDATE );
  ETL_PAC_MEMBER_TAGS_RELATION(PIDATE  );
  ETL_PAC_TAGS(PIDATE );
 -- ETL_PAC_ERP_ORDER(PIDATE );
 -- ETL_PAC_ERP_ORDER_ITEM(PIDATE );
 
 
   END;
  


end ETL_CRM_DATA;
/

