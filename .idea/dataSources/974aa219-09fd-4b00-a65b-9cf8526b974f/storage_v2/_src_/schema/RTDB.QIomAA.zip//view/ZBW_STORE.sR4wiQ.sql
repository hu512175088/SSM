create view ZBW_STORE as
  select "SHPCODE","SKU","ITEMCODE","LOCCODE","QTY1" from bn_biz_store_rt
/

