create view ZBW_POSRETRIEVE as
  select b."MA_FMID",b."DE_FMID",b."MA_FSID",b."FPID",b."FSCODE",b."FFID",b."FCODE",b."FNAME",b."FSTATE",b."FAMOUNT_BASE",b."FAMOUNT_SALE",b."FAMOUNT_DISCRATE",b."FREMARK",b."FINDEX",a.FMID as RE_FMID,a.Fpid as RE_FPID,a.fcode as RE_FCODE,a.ffid as RE_FFID,a.famount_base as RE_FAMOUNT_BASE,a.findex as RE_FINDEX,
       a.fprice_sale as RE_FPRICE_SALE,a.famount_cost as RE_FAMOUNT_COST,a.famount_discrate as RE_FAMOUNT_DISCATE,a.fproperty_value
from BN_BIZ_RETRIEVE_DE a left join ZBW_POSPAY b on a.FMID=b.FSCODE
where b.FNAME='旧料旧货'
/

