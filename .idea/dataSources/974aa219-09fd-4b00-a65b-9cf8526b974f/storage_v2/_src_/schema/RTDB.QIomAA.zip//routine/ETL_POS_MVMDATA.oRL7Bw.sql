create procedure ETL_POS_MVMDATA is
 VMSG    VARCHAR2(255);
begin
  dbms_mview.refresh('BN_BIZ_SA_SP');
  dbms_mview.refresh('BN_SYS_ORG');
  dbms_mview.refresh('BN_SYS_ORG_INFO');
--SKU
  dbms_mview.refresh('BN_BIZ_SKU');
  dbms_mview.refresh('BN_BIZ_GOODS');
  dbms_mview.refresh('BN_BIZ_SKU_ATT');
  dbms_mview.refresh('bn_biz_spu');
--销售计划
 dbms_mview.refresh('BN_BIZ_SATA_DE');
 
 dbms_mview.refresh('bn_biz_brokerage_de');
 dbms_mview.refresh('bn_biz_rp_buy');
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('MVMDATA_VIEW', sysdate, trunc(sysdate), substr('过程出错' || VMsg, 1, 255));
        commit;
end ETL_POS_MVMDATA;
/

