create view ZCRM_R014 as
  SELECT TO_CHAR(B."create_time",'yyyy-mm') AS 使用时间,"interval_history" AS "积分记录(负为使用)",
"accumulat_points" AS 有效积分,"remark" as 退款追扣,"sum_points" AS 总积分,C.FA002_NAME as 销售地区,"SUBSTR"(to_char(B."create_time",'yyyy-mm'), 6, 2) AS 月
FROM CRM_tab_gic_member A
LEFT JOIN tab_gic_member_interval_log B ON A."member_id"=B."member_id"
left join BN_SYS_ORG_INFO C on A."store_code"=C.FCODE
WHERE "interval_history" <0
and A."card_num" <> -1
group by  "interval_history", "accumulat_points", "remark", "sum_points", C.FA002_NAME, 
A."card_num", B."create_time"
/

