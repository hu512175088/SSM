create view ZBW_PLNDAY as
  select "FMID","销售地区","区经","区总","SHPCODE","ITEMTYPE","ZDATE","PLANSALES","门店属性","门店名称" from BN_BIZ_SATA_DE
/

