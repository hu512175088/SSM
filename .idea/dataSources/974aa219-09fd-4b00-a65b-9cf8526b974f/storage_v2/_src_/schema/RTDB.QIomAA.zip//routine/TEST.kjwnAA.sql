create procedure test is
begin
  declare
i number(5);
 VDATE date; 
begin
    i:=1;
    vDATE := sysdate-668;--TRUNC(sysdate);
    while i<5600 loop
   -- dbms_output.put_line('while循环：'||i);
   insert into calday 
  select trunc(vDATE) as vdate,to_char(vDATE,'yyyy') as vyear ,to_char(vDATE,'mm') as vmonth,to_char(vDATE,'day','NLS_DATE_LANGUAGE=''SIMPLIFIED CHINESE''') as vweek,
  TO_CHAR(vDATE, 'WW') as vwweknum,
  to_char(TRUNC(TO_DATE(to_char(vDATE,'yyyy-MM-dd'),'yyyy-MM-dd'),'IW'),'yyyy-MM-dd')  as weekstr,
  to_char(TRUNC(TO_DATE(to_char(vDATE,'yyyy-MM-dd'),'YYYY-MM-DD'),'IW') + 6,'yyyy-MM-dd') as weekend
   from dual;
   
    commit;
    i:=i+1;
    vDATE:= vDATE + 1;
    end loop;
end;
end test;
/

