create view ZCRM_R008 as
  SELECT  a.cardno, a.DOCNUM ,substr(a.EXITDATE,1,4)||'-'||substr(a.EXITDATE,5,2) as 年月,substr(a.EXITDATE,5,2) as 月,substr(a.EXITDATE,7,2) as 日,
	a.SHPCODE,(SUBSTR(d.FA003_NAME,0,2)||d.FA002_NAME) AS 区域,
--b."GoodsNo",--b."SkuCode",
  FUN_SPLIT_ONE(c.FPROPERTY_VALUE,'/',6) AS 分类,d."FA002_NAME",
	"COUNT"(DISTINCT a.DOCNUM) as 订单数,COUNT(1) as 件数
FROM ZBW_POSSALES_CRM_MAIN a
	LEFT JOIN BN_BIZ_SKU c on a.ITEMCODE = c.FCODE
	LEFT JOIN BN_SYS_ORG_INFO d on a.SHPCODE = d."FPCODE"
where nvl(a.cardno,'-1') > '-1' and FUN_SPLIT_ONE(c.FPROPERTY_VALUE,'/',6) in ('黄金','非黄')
      and PRICETYPE IN ( '销售','套装') AND SYSCOST <> 0
      and ((SUBSTR(d.FA003_NAME,0,2)||d.FA002_NAME) LIKE '加盟%' OR (SUBSTR(d.FA003_NAME,0,2)||d.FA002_NAME) LIKE '直营%')
GROUP BY a.cardno, a.DOCNUM ,substr(a.EXITDATE,1,4)||'-'||substr(a.EXITDATE,5,2),substr(a.EXITDATE,5,2) ,substr(a.EXITDATE,7,2),
	a.SHPCODE,a.ITEMCODE,a.SKU,FUN_SPLIT_ONE(c.FPROPERTY_VALUE,'/',6) ,d."FA002_NAME",(SUBSTR(d.FA003_NAME,0,2)||d.FA002_NAME)
/

