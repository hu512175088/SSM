create view ZBW_SKU as
  select replace(ltrim(replace("MATERIAL",'0',' ')),' ','0') as SKU,"skuname" SKU名称,
       a."dlname" as 一级分类,a."spdlname" as 二级分类,a."slname" as 石类,
       replace(ltrim(replace(a."/BIC/ZCPGG",'0',' ')),' ','0') as 规格,a."ggname" as 规格名,
       a."xmname" as 项目,a."xlname" as 系列,a."yybame" as 寓意,a."lbname" as 佩戴类别,
       a."dxlname" as 大系列,a."spflname" as 三级分类,a."jlname" as 金类
from sap_skuatt a
where a."dlname" is not null
/

