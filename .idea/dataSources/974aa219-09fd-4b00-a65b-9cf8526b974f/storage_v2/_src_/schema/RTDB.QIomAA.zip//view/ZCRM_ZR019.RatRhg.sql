create view ZCRM_ZR019 as
  select (SUBSTR(b.FA003_NAME,0,2)||b.FA002_NAME)  AS 销售区域,
			 substr(A.EXITDATE,1,4)||'-'||substr(A.EXITDATE,5,2)||'-'||substr(A.EXITDATE,7,2) AS 消费时间,
			 a.CARDNO as 会员手机号,b."FA030_NAME" AS 区经,
       a.SHPCODE AS 门店,e."wx_member",sum(CASE WHEN d."tags_name" is not null then 1 else 0 end) as 标签 ,
       a.FOPOR,
       count(DISTINCT A.DOCNUM) AS 日合计
FROM ZBW_POSSALES_CRM_MAIN A 
			left join BN_SYS_ORG_INFO B on A.SHPCODE = B.FCODE
			LEFT JOIN CRM_TAB_GIC_MEMBER e ON e."card_num" = a.cardno
			LEFT JOIN TAB_GIC_MEMBER_TAGS_RELATION c ON c."member_id" = e."member_id"
			LEFT JOIN CRM_TAB_GIC_TAGS d on d."tags_id" = c."tags_id"
WHERE (a.SHPCODE <> '5055' and a.SHPCODE <> '5057' and a.SHPCODE <> '5574' and a.SHPCODE <> '5069'
			 and a.SHPCODE <> 'saler_E3' and a.SHPCODE <> '5274' and a.SHPCODE <> '5271')
			 and a.PRICETYPE IN ( '销售','套装') and SYSCOST <> '0' 
			 and ((SUBSTR(b.FA003_NAME,0,2)||b.FA002_NAME) LIKE '加盟%' OR (SUBSTR(b.FA003_NAME,0,2)||b.FA002_NAME) LIKE '直营%') 
       and SYSCOST <> '0' and a.FOPOR NOT like '%内购%'                       
group by (SUBSTR(b.FA003_NAME,0,2)||b.FA002_NAME), 
					substr(A.EXITDATE,1,4)||'-'||substr(A.EXITDATE,5,2)||'-'||substr(A.EXITDATE,7,2), 
          a."CARDNO", a.SHPCODE,e."wx_member",b."FA030_NAME",a.FOPOR
/

