create view ZCRM_R016 as
  SELECT  
a.cardno as 会员卡号, 
a.DOCNUM as 订单号,
substr(a.EXITDATE,1,4)||'-'||substr(a.EXITDATE,5,2) AS 年月,
substr(a.EXITDATE,5,2) AS 月,
d."FA002_NAME" as 区域,
b."tags_name" as 会员标签,
a.SYSCOST as 实付金额,
a.SHPCODE AS 门店,
a.FOPOR,
COUNT(*) as 计数
FROM ZBW_POSSALES_CRM_MAIN a
LEFT JOIN BN_SYS_ORG_INFO d on a.SHPCODE = d."FPCODE"
LEFT JOIN CRM_TAB_GIC_MEMBER e ON e."card_num" = a.cardno
LEFT JOIN TAB_GIC_MEMBER_TAGS_RELATION c ON c."member_id" = e."member_id"
LEFT JOIN CRM_TAB_GIC_TAGS b on b."tags_id" = c."tags_id"
where  a.cardno is not null and a.SYSCOST > 0 and (a.SHPCODE <> 'saler_E3' and a.SHPCODE 

<> '5274' and a.SHPCODE <> '5271') and e."wx_member" = '1'  and SYSCOST <> '0' and a.FOPOR NOT like '%内购%' 
GROUP BY a.cardno,a.SYSCOST,
a.DOCNUM,
substr(a.EXITDATE,1,4)||'-'||substr(a.EXITDATE,5,2),
substr(a.EXITDATE,5,2),
d."FA002_NAME",
b."tags_name",
a.SHPCODE,
a.FOPOR
/

