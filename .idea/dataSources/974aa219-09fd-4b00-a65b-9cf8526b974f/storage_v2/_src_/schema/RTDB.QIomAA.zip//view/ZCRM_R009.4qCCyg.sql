create view ZCRM_R009 as
  SELECT 
    "会员号","订单号",单品销售金额,"订单日期","月","日","分类","区域"
FROM
(
    SELECT 
        NVL(a.CARDNO,-1) AS 会员号,a.DOCNUM AS 订单号 ,NVL(a.SYSCOST,0) as 单品销售金额,
        substr(a.EXITDATE,1,4)||'-'||substr(a.EXITDATE,5,2) AS 订单日期,
        substr(a.EXITDATE,5,2) AS 月,substr(a.EXITDATE,7,2) AS 日,FUN_SPLIT_ONE(d.FPROPERTY_VALUE,'/',6) AS 分类 ,
        (SUBSTR(b.FA003_NAME,0,2)||b.FA002_NAME) AS 区域
    FROM
        (SELECT * FROM ZBW_POSSALES_CRM_MAIN WHERE PRICETYPE IN ( '销售','套装') AND SYSCOST <> 0)a
        LEFT JOIN BN_BIZ_SPU d on a.SKU = d.FMID
        JOIN BN_SYS_ORG_INFO b ON a.SHPCODE = b.FPCODE
        where  a.SHPCODE <> '5055' and a.SHPCODE <> '5057' and a.SHPCODE <> '5574' and a.SHPCODE <> '5069'
                     and a.SHPCODE <> 'saler_E3' and a.SHPCODE <> '5274' and a.SHPCODE <> '5271'

) C 
where 
    (分类 = '黄金' or 分类 = '非黄') 
    --AND NVL(单品销售金额,0) <> 0 
    AND (区域 LIKE '加盟%' OR 区域 LIKE '直营%')
/

