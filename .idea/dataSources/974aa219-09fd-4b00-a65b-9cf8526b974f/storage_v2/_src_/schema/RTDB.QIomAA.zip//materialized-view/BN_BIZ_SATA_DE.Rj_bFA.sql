create materialized view BN_BIZ_SATA_DE
refresh complete on demand
  as
    select a.fmid,b.FA002_NAME as 销售地区,b.FA030_NAME as 区经,b.FA029_NAME as 区总,forg_code as SHPCODE ,findex as itemtype,to_date(( fmonth || fday ),'yyyy-mm-dd')as ZDATE,
			 famount_base as plansales,case when b.FA023_NAME = '加盟店' then '加盟店' ELSE '直营店' END AS 门店属性,b.FNAME as 门店名称
from pos.bn_biz_sata_de@posprd a,BN_SYS_ORG_INFO b 
where fmonth >= '201809' and a.forg_code=b.FCODE
/

