create procedure ETL_POS_MVSALES is
 VMSG    VARCHAR2(255);
begin
   dbms_mview.refresh('bn_biz_sa_ma');
   dbms_mview.refresh('bn_biz_sa_de');
   dbms_mview.refresh('bn_biz_store');
   dbms_mview.refresh('BN_BIZ_PAY_SPM');
   dbms_mview.refresh('BN_BIZ_PAY_MA');
   dbms_mview.refresh('BN_BIZ_PAY_DE');
   dbms_mview.refresh('BN_BIZ_RETRIEVE_DE');
   dbms_mview.refresh('BN_BIZ_MRR_DE');
   dbms_mview.refresh('BN_BIZ_SPM_MA');
   dbms_mview.refresh('BN_BIZ_REPAIR_MA');
   
   dbms_mview.refresh('BN_BIZ_REPAIR_DE');
   dbms_mview.refresh('bn_biz_store_rt');
   
    EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('MV_VIEW', sysdate, trunc(sysdate), substr('过程出错' || VMsg, 1, 255));
        commit;
end ETL_POS_MVSALES;
/

