create view ZBW_POSSALES_MAIN as
  SELECT a.SHPCODE,a.DOCNUM,a.LINENUM,a.EXITDATE,a.SKU,a.ITEMCODE,a.DOCDATE,a.ADSCENTRYS,a.EMPCODE,a.SALEMAKER,a.RECHECK,a.FEETYPE,a.RDOCNUM,a.CARDID,a.CUSPHONE,a.CUSCODE,a.CUSNAME,
       a.INVOICECODE,a.ISNEED,a.AUDIT1 as AUDIT1,a.INVOICECODE1,a.RETURNTYPE,a.REPAIRADDRESS,a.LASTDATE,a.SOURCETYPE,a.SOURCENUM,a.AGRDELDATE,a.REMAINNAME,a.MAKER,a.POINT1 as POINT1,
       a.COST1 as COST1,a.GOLDNUM,a.USEPOINT,a.USEBALANCE,
       case when a.SOURCETYPE='1' then 0-a.QTY1 else a.QTY1 end as QTY1,  --数量
       a.EARNEST,a.BALANCE,a.ADDPOINT,a.WEIGHT,
       case when a.SOURCETYPE='1' then 0-a.MARKEDPRICE else a.MARKEDPRICE end as MARKEDPRICE, --上柜价（折前价）
       a.PRICETYPE,a.HANDS,a.USEDPOINT,a.DONEFEE,
       case when a.SOURCETYPE='1' then 0-a.LINETOTAL else a.LINETOTAL end as LINETOTAL,       --成交金额
       a.DAYPRICE2,a.DAYPRICE2 as DAYPRICE1,a.FORCASH,
       case when a.SOURCETYPE='1' then 0-a.DISCOUNT1 else a.DISCOUNT1 end as DISCOUNT1,       --旧货旧料金额
       a.MEMWHALEY,a.MEMCOUPOS,
       case when a.SOURCETYPE='1' then 0-a.FEETOTAL else a.FEETOTAL end as FEETOTAL,          --商城回款（扣率后金额）
       a.STORECOST,a.COUPONS,
       case when a.SOURCETYPE='1' then 0-a.SYSCOST else a.SYSCOST end as SYSCOST,             --商场金额+商场收券
       a.MALLSTAMPS,a.STONENUM,a.AFTERWEIGHT,a.BEFOREWEIGHT,
       case when a.SOURCETYPE='1' then 0-a.PRICE else a.PRICE end as PRICE,             --销售单价
       a.REMAINQTY,a.REMAINWEIGHT,
       case when a.SOURCETYPE='1' then 0-a.DISCOUNT else a.DISCOUNT end as DISCOUNT,    --折扣总额
       case when a.SOURCETYPE='1' then 0-a.DISCOUNTPRICE else a.DISCOUNTPRICE end as DISCOUNTPRICE, --折扣总额
       a.LOCCODE,a.FEE,a.ISINSIDE,a.TYPE1,a.MEMO
FROM zbw_possales a
 --where a.EXITDATE>='20180724' and a.EXITDATE<='20180914'
 where a.EXITDATE=to_char(sysdate-1,'yyyymmdd') or (a.ftrans_state=3 and a.ftrans_time=to_char(sysdate-1,'yyyymmdd'))
/

