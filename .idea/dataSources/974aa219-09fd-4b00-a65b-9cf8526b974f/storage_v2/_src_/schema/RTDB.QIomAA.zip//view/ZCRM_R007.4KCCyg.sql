create view ZCRM_R007 as
  select
fa002_name as qy,
fa006_name as qj,
to_char("member_birthday",'yyyy-mm') as hysr,
to_char("member_birthday",'mm') as hysry,
"grade_code" as hydj,count("card_num") as hyrs
from crm_tab_gic_member a,crm_tab_gic_member_personal b, BN_SYS_ORG_INFO s
where a."member_id"=b."member_id" and  a."store_code"=s.fpcode and a."card_num" <> -1 and "store_code" not in('saler_E3','5274','5271')
group by fa002_name,fa006_name,to_char("member_birthday",'yyyy-mm'),to_char("member_birthday",'mm'),"grade_code"
/

