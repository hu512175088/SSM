create view ZBW_POSSALES_MAIN_NEW_QWMD as
  Select "销售区域","区总","区经","门店代码","门店名称","门店属性","商品大类","二级分类","小票号","小票行号","过账日期","SKU","SKU名","批次编码","批次名称","单据创建日期","开票码","小票类型","制单人工号","业绩归属人","数量","上柜价","小票行类型","成交金额","商城回款","商场金额","销售单价","库存地点","开票码扣率","是否内购" 
from zbw_possales_main_new a
where exists(select ZNO from zrtdb_insert001 b where b.zno=a.门店代码)
/

