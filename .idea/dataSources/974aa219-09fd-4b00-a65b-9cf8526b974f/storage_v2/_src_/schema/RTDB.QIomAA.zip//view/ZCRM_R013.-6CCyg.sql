create view ZCRM_R013 as
  select B."FA002_NAME" AS 销售区域,substr(A.EXITDATE,1,4)||'-'||substr(A.EXITDATE,5,2) AS 消费时间,count(DISTINCT A.DOCNUM) AS 日合计,a.CARDNO as 会员手机号,
    substr(A.EXITDATE,5,2) AS 月,substr(A.EXITDATE,7,2) AS 日,a.SHPCODE AS 门店,a.FOPOR
FROM ZBW_POSSALES_CRM_MAIN A 
left join BN_SYS_ORG_INFO B on A.SHPCODE = B.FCODE
WHERE (a.SHPCODE <> '5055' and a.SHPCODE <> '5057' and a.SHPCODE <> '5574' and a.SHPCODE <> '5069'
                     and a.SHPCODE <> 'saler_E3' and a.SHPCODE <> '5274' and a.SHPCODE <> '5271')
                     and a.PRICETYPE IN ( '销售','套装') and SYSCOST <> '0' and a.FOPOR NOT like '%内购%'                                   
group by   B."FA002_NAME", substr(A.EXITDATE,1,4)||'-'||substr(A.EXITDATE,5,2), a."CARDNO", substr(A.EXITDATE,5,2),substr(A.EXITDATE,7,2),a.SHPCODE,a.FOPOR
/

