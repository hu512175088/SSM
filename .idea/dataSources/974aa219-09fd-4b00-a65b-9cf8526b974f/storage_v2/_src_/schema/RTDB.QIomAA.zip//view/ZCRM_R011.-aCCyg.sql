create view ZCRM_R011 as
  SELECT 会员号,单号,订单日期,SKU码,产品名称,产品属性,年龄,年龄段,标签 FROM ( 
  SELECT 
    --C."phone_number" AS 会员号,
    ord.CARDNO AS 会员号,
    ord.DOCNUM AS 单号,
    SUBSTR(ord.EXITDATE,1,4)||'-'||SUBSTR(ord.EXITDATE,5,2) AS 订单日期,
    FUN_SPLIT_ONE(d.FPROPERTY_VALUE,'/',6) AS 分类,
    --d.FSPU_ID AS SKU码,
    ord.SKU AS SKU码,
    d.FNAME AS 产品名称,
    FUN_SPLIT_ONE(d.FPROPERTY_VALUE,'/',10)||FUN_SPLIT_ONE(d.FPROPERTY_VALUE,'/',16) AS 产品属性 ,
    c.NUM_AGE as 年龄,
    CASE WHEN c.NUM_AGE < 26 THEN '25岁以下' 
         WHEN c.NUM_AGE BETWEEN 26 AND 30 THEN '26-30岁'
         WHEN c.NUM_AGE BETWEEN 31 AND 35 THEN '21-35岁'
         WHEN c.NUM_AGE BETWEEN 36 AND 40 THEN '36-40岁'
         WHEN c.NUM_AGE BETWEEN 41 AND 50 THEN '41-50岁'
         WHEN c.NUM_AGE > 51 THEN '50岁以上'
         ELSE '25岁以下'
    END AS 年龄段,
    e."tags_name" as 标签
    FROM 
        (SELECT * FROM ZBW_POSSALES_CRM_MAIN WHERE SYSCOST > '0') ord
        LEFT JOIN BN_BIZ_SPU d on ord.SKU = d.FMID  
        LEFT JOIN 
            (SELECT "phone_number","member_personal_id","member_id",(TO_CHAR(SYSDATE,'YYYY')-TO_CHAR("member_birthday",'YYYY')) AS NUM_AGE 
                FROM 
                    crm_tab_gic_member_personal 
                WHERE "member_birthday" IS NOT NULL 
                ) c
            ON ord.CARDNO = c."phone_number"
        left JOIN tab_gic_member_tags_relation e ON e."member_id" = c."member_id"
WHERE NVL(ord.CARDNO,-1) > '-1'
)
WHERE 分类 = '非黄' OR 分类 = '黄金'
/

