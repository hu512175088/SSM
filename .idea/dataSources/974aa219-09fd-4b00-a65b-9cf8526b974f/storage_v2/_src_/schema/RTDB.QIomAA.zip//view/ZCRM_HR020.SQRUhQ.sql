create view ZCRM_HR020 as
  SELECT a.门店代码,a.开卡年月,a.消费年月,a.卡号,a.FOPOR,
       case when a.消费年月=a.开卡年月 then '新会员'		
            when a.开卡年月<>a.消费年月 and a.消费次数 > 1 then '老会员' 
            when a.开卡年月<>a.消费年月 and a.消费次数 = 1 THEN '潜力会员' end as 会员类型 ,
"SUM"(a.消费金额) as 消费金额,a.区域,
SUM(case when a.消费金额 >= 0 then 1 ELSE -1 end )  as 单数
from (
SELECT
b.cardno as 卡号,b.DOCNUM,
b.EXITDATE as 消费时间,
--substr(b.EXITDATE,1,4)||'-'||substr(b.EXITDATE,5,2)  as 消费年月,
--substr(b.EXITDATE,5,2) AS 月,
substr(b.EXITDATE,1,4)||'-'||substr(b.EXITDATE,5,2)||'-'||substr(b.EXITDATE,7,2)  as 消费年月,
b.DOCNUM AS 消费单,
a."card_giving_time" as 开卡时间,
a."store_code" as 门店代码,
c."FA002_NAME" AS 区域,
b.SYSCOST as 消费金额,
b.FOPOR,
e."cost_times" as 消费次数,
"TO_CHAR"(a."card_giving_time",'yyyy-mm-dd') as 开卡年月
--"TO_CHAR"(a."card_giving_time",'mm') as 开卡月
from ZBW_POSSALES_CRM_MAIN b 
LEFT JOIN crm_tab_gic_member a on b.cardno = a."card_num" 
--LEFT JOIN POS_TAB_ERP_ORDER_ITEM d on b."OrderSerial" = d."OrderSerial"
LEFT JOIN BN_BIZ_SKU z on b.ITEMCODE=z.FCODE 
LEFT JOIN BN_SYS_ORG_INFO c on b.SHPCODE = c."FCODE"
LEFT JOIN CRM_TAB_GIC_MEMBER_INFO e on a."member_id" = e."member_id"
--LEFT JOIN ZBW_POSSALES_MAIN_NEW x on b.DOCNUM = x."小票号" 
where cardno is NOT NULL and      
       (c.FA003_NAME LIKE '加盟%' OR c.FA003_NAME LIKE '直营%' OR c.FA003_NAME LIKE 'da%') AND
			 --FUN_SPLIT_ONE(z.FPROPERTY_VALUE,'/',6) in('非黄','黄金') 
       PRICETYPE IN ( '销售','套装') and SYSCOST <> 0
       and  b.FOPOR NOT like '%内购%'  
) a 
GROUP BY a.门店代码,a.开卡年月,a.消费年月, a.卡号,a.区域,a.FOPOR,
    case when a.消费年月=a.开卡年月 then '新会员'		
           when a.开卡年月<>a.消费年月 and a.消费次数 > 1 then '老会员' 
          when a.开卡年月<>a.消费年月 and a.消费次数 = 1 THEN '潜力会员' end
/

