create view ZBW_POSSALES_NEW as
  SELECT case when a.Findex=11 then to_char(SUBSTR(a.Fde_Code,1,4)) when a.Findex=21 then to_char(SUBSTR(a.Fre_Code,1,4)) end AS SHPCODE,
     NVL(FUN_SPLIT_ONE(b.FPROPERTY_VALUE,'/',1),'空') AS EJFL1,
     a.FCODE AS DOCNUM,b.FFID AS LINENUM,to_char(a.FBIZTIME,'yyyymmdd') AS EXITDATE,to_char(d.Fspu_Id) AS SKU,
     to_char(d.FNAME) AS SKU_NAME1,
     to_char(b.Fsku_Code) AS ITEMCODE,to_char(a.Fcreatetime,'yyyymmdd') AS DOCDATE,to_char(b.Frate_Code) AS INVOICECODE,
     to_char(a.Fupdatetime,'yyyymmdd') AS LASTDATE,
     case when a.Findex=11 then '0' when a.Findex=21 then '1' end AS SOURCETYPE,
     a.Fscode AS SOURCENUM,a.Foperatorid AS MAKER,b.FQTY_BASE AS QTY1,
     case when b.Fprice_Sale is null then b.Famount_Base else b.Fprice_Sale end AS MARKEDPRICE,
     case when c.FNAME='内购' then '内购' when b.fsku_code like'500000%' then '费用' when a.Findex=11 then '销售' when a.Findex=21 then '退货' end AS PRICETYPE,
     b.Famount_Base AS LINETOTAL,
     case when Frate_Value is null then b.Famount_Base else b.Famount_Base * (1-b.Frate_Value/100) end AS FEETOTAL,
     case when b.Fprice_Sale is null then b.Famount_Base when i.SPR_ZKJE2 is null then 0 else i.SPR_ZKJE2 end as SYSCOST,
     b.Famount_Sale AS PRICE,
     case when a.Findex=11 then to_char(SUBSTR(a.Fde_Code,5,4)) when a.Findex=21 then to_char(SUBSTR(a.Fre_Code,5,4)) end AS LOCCODE,
     case when Frate_Value is null then 0 else b.Frate_Value/100 end AS FEE,case when c.FNAME='内购' then 1 else 0 end AS ISINSIDE,
     to_char(e.fname) AS TYPE1,b.fremark AS MEMO,a.fmid as FMID,a.ftrans_state as ftrans_state,
     to_char(a.ftrans_time,'yyyymmdd') as ftrans_time,MD.FNAME as FNAME_MD,TO_CHAR(MDE.FA002_NAME) AS FQY,
     TO_CHAR(MDE.FA029_NAME) AS FQZ,TO_CHAR(MDE.FA030_NAME) AS FQJ,TO_CHAR(SP.FNAME) AS FOPOR,
     to_char(substr(b.fproperty_value,instr(b.fproperty_value,'/',1,5)+1,2)) as ZDL,MDE.FA023_NAME AS FATT_MD,
     to_char(b.FSKU_NAME) as FSKU_NAME
FROM  BN_BIZ_SA_DE b left join ZV_BN_BIZ_SA_MA a on A.FMID=B.FPID
                  left join (select distinct MA_FSID,Fname from zbw_pospay where Fname='内购') c on b.FPID=c.MA_FSID --判断内购
                  left join BN_BIZ_SKU d on b.Fsku_Code=d.FCODE  --取SKU
                  left join BN_BIZ_MRR_DE e on b.frate_id=e.fmid --取开票码大类
                  LEFT JOIN BN_BIZ_SA_SP SP ON a.FMID=SP.FPID AND SUBSTR(SP.FINDEX,2,1)=1
                  INNER JOIN BN_SYS_ORG ORG ON ORG.FMID=NVL(a.FRE_ID,a.FDE_ID)
                  LEFT JOIN BN_SYS_ORG MD ON MD.FNCODE=ORG.FPCODE
                  LEFT JOIN BN_SYS_ORG_INFO MDE ON MDE.FMID=MD.FMID
                  left join (select Y.FRID,sum(Y.famount_base) as SPR_ZKJE1,sum(Y.famount_sale) as SPR_ZKJE2,sum(Y.famount_discrate) as SPR_ZKJE3
                             from bn_biz_pay_spm Y
                             where Fname in('商场收银','商场收券','现金','银行卡','微信','支付宝','旧料旧货','定金','折旧费','内购')
                             group by Y.FRID) i on b.fmid=i.FRID --取商场金额
WHERE a.Fstate=50 and a.ftrans_state <> 99 and substr(b.fproperty_value,instr(b.fproperty_value,'/',1,5)+1,2) in('黄金','非黄')
union all
--销售（老POS业务类型：旧货、旧料）
SELECT case when a.Findex=11 then to_char(SUBSTR(a.Fde_Code,1,4)) when a.Findex=21 then to_char(SUBSTR(a.Fre_Code,1,4)) end AS SHPCODE,
       NVL(FUN_SPLIT_ONE(b.FPROPERTY_VALUE,'/',1),'空') AS EJFL1,
       a.FCODE AS DOCNUM,b.ffid AS LINENUM,to_char(a.FBIZTIME,'yyyymmdd') AS EXITDATE,to_char(c.FSPU_ID) AS SKU,
       to_char(c.FNAME) AS SKU_NAME1,to_char(b.RE_FCODE) AS ITEMCODE,to_char(a.Fcreatetime,'yyyymmdd') AS DOCDATE,'NONE' AS INVOICECODE,
       to_char(a.Fupdatetime,'yyyymmdd') AS LASTDATE,case when a.Findex=11 then '0' when a.Findex=21 then '1' end AS SOURCETYPE,
       a.Fscode AS SOURCENUM,a.Foperatorid AS MAKER,-1 AS QTY1,0-b.RE_Famount_Base AS MARKEDPRICE,
       case when b.RE_FINDEX='10' then '旧料' when b.RE_FINDEX='20' then '旧货' when b.RE_FINDEX='21' then '旧料' end AS PRICETYPE,
       0-b.RE_Famount_Base AS LINETOTAL,0.00 AS FEETOTAL,
       0-b.Famount_sale AS SYSCOST,0.00 AS PRICE,'0001' AS LOCCODE,0.00 AS FEE,
       case when b.FNAME='内购' then 1 else 0 end AS ISINSIDE,'NONE' AS TYPE1,b.fremark AS MEMO,a.fmid as FMID,
       1 as ftrans_state,to_char('','yyyymmdd') as ftrans_time,
       MD.FNAME as FNAME_MD,TO_CHAR(MDE.FA002_NAME) AS FQY,
       TO_CHAR(MDE.FA029_NAME) AS FQZ,TO_CHAR(MDE.FA030_NAME) AS FQJ,
       TO_CHAR(SP.FNAME) AS FOPOR,
       case when b.RE_FINDEX='10' then to_char('旧料') when b.RE_FINDEX='20' then to_char('旧货') when b.RE_FINDEX='21' then to_char('旧料') end AS ZDL,
       MDE.FA023_NAME AS FATT_MD,to_char(c.FNAME) AS FSKU_NAME
FROM ZBW_POSRETRIEVE b  left join ZV_BN_BIZ_SA_MA a on a.fmid=b.MA_FSID
                        left join bn_biz_sku c on c.FCODE=b.RE_FCODE
                        LEFT JOIN BN_BIZ_SA_SP SP ON a.FMID=SP.FPID AND SUBSTR(SP.FINDEX,2,1)=1
                        INNER JOIN BN_SYS_ORG ORG ON ORG.FMID=NVL(a.FRE_ID,a.FDE_ID)
                        LEFT JOIN BN_SYS_ORG MD ON MD.FNCODE=ORG.FPCODE
                        LEFT JOIN BN_SYS_ORG_INFO MDE ON MDE.FMID=MD.FMID
WHERE a.Fstate=50 and a.ftrans_state <> 99 and b.FNAME='旧料旧货'
/

