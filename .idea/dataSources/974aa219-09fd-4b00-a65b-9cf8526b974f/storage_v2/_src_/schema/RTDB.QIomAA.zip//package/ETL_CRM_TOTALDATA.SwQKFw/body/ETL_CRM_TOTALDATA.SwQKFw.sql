create package body ETL_CRM_TOTALDATA is

  
 VMSG    VARCHAR2(255);
 

 PROCEDURE ETL_PAC_STORE(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_store ;
 insert into  CRM_TAB_GIC_store select * from "tab_gic_store"@mysql; 
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_store; 
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_STORE', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_store', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
     
 end;
 --***************************************************************
  PROCEDURE ETL_PAC_CLERK(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_CLERK ;
 insert into  CRM_TAB_GIC_CLERK select * from "tab_gic_clerk"@mysql; 
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_CLERK ; 
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_CLERK', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_CLERK', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
     
 end;
--***************************************************************************
 PROCEDURE  ETL_PAC_COUP_CARD(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_COUP_CARD; 
 insert into CRM_TAB_GIC_COUP_CARD("coup_card_id", 
  "enterprise_id" , 
  "card_type" , 
  "card_name" , 
  "sub_name" , 
  "sub_title" , 
  "card_color" , 
  "use_condition" , 
  "card_limit" , 
  "card_code_count" , 
  "card_effective_mode" , 
  "begin_date" , 
  "end_date" , 
  "start_day", 
  "limit_day" , 
  "image_field_code" , 
  "image_url", 
  "qcloud_image_url", 
  "cover_descript" , 
  "verification_type" , 
  "create_date" , 
  "update_time" , 
  "auditing_status" , 
  "status" , 
  "member_range" , 
  "coupon_stock" , 
  "issuing_quantity" , 
  "geted_quantity", 
  "usage_quantity", 
  "sale_amount" , 
  "giving_num", 
  "store_mode" , 
  "wechat_card_id" , 
  "card_explain" , 
  "use_custom_code" , 
  "custom_code_begin" , 
  "custom_code_end", 
  "custom_code_prefix" , 
  "custom_code_suffix", 
  "use_code_prefix", 
  "use_code_suffix", 
  "custom_code_sync" , 
  "cost_value", 
  "clique_id" , 
  "channel_type", 
  "applicable_mode" , 
  "applicable_mall_pro_mode" , 
  "applicable_store_pro_mode", 
  "not_applicable_mode" , 
  "not_applicable_mall_pro_mode" , 
  "not_applicable_store_pro_mode" , 
  "calculation_method" , 
  "tag_code", 
  "shelf_type", 
  "shelf_tag_code" , 
  "erp_demo_code" )
 select  "coup_card_id","enterprise_id","card_type" , "card_name","sub_name","sub_title","card_color","card_denomination"
"use_condition","card_limit","card_code_count","card_effective_mode","begin_date","end_date","start_day","limit_day",
"image_field_code","image_url","qcloud_image_url","cover_descript","verification_type","create_date","update_time",
"auditing_status","status","member_range","coupon_stock","issuing_quantity","geted_quantity","usage_quantity","sale_amount",
"giving_num","store_mode","wechat_card_id","card_explain","use_custom_code","custom_code_begin","custom_code_end","custom_code_prefix",
"custom_code_suffix","use_code_prefix","use_code_suffix","custom_code_sync","cost_value","clique_id","channel_type","applicable_mode",
"applicable_mall_pro_mode","applicable_store_pro_mode","not_applicable_mode","not_applicable_mall_pro_mode","not_applicable_store_pro_mode",
"calculation_method","tag_code","shelf_type","shelf_tag_code","erp_demo_code"
from "tab_gic_coup_card"@mysql  ;
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_COUP_CARD ;
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_COUP_CARD', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_COUP_CARD', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
     
 end;
 --***********************************************
  PROCEDURE ETL_PAC_COUP_CARD_LOG(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_COUP_CARD_LOG ;
 insert into  CRM_TAB_GIC_COUP_CARD_LOG select * from "tab_gic_coup_card_log"@mysql  ;
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_COUP_CARD_LOG ;
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_CLERK', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_COUP_CARD_LOG', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
     
 end;
 --****************************************************
  PROCEDURE ETL_PAC_EVALUATE_MSG_LOG(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_EVALUATE_MSG_LOG ;
 insert into  CRM_TAB_GIC_EVALUATE_MSG_LOG select * from "tab_gic_evaluate_msg_log"@mysql ;
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_EVALUATE_MSG_LOG ;
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_EVALUATE_MSG_LOG', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_EVALUATE_MSG_LOG', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   --no update_time  
 end;
 --**********************************************************
  PROCEDURE ETL_PAC_MEMBER(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_MEMBER ;
 insert into  CRM_TAB_GIC_MEMBER select * from "tab_gic_member"@mysql ; 
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_MEMBER ; 
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_MEMBER', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_MEMBER', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
     
 end;
 --***************************************************************
 PROCEDURE ETL_PAC_MEMBER_CLERK(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_MEMBER_CLERK ;
 insert into  CRM_TAB_GIC_MEMBER_CLERK select * from "tab_gic_member_clerk"@mysql ;
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_MEMBER_CLERK ;
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_MEMBER_CLERK', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_MEMBER_CLERK', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
     
 end;
 --*************************************
 PROCEDURE ETL_PAC_MEMBER_FIELD_VALUE(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_MEMBER_FIELD_VALUE ;
 insert into CRM_TAB_GIC_MEMBER_FIELD_VALUE select * from "tab_gic_member_field_value"@mysql ;
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_MEMBER_FIELD_VALUE  ;
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_MEMBER_FIELD_VALUE', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_MEMBER_FIELD_VALUE', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
--***************************************************************
PROCEDURE ETL_PAC_MEMBER_INFO(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_MEMBER_INFO ;
 insert into CRM_TAB_GIC_MEMBER_INFO select * from "tab_gic_member_info"@mysql  ;
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_MEMBER_INFO  ;
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_MEMBER_INFO', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_MEMBER_INFO', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;

PROCEDURE ETL_PAC_MEMBER_INTERVAL_LOG(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM TAB_GIC_MEMBER_INTERVAL_LOG ;
 
 insert into TAB_GIC_MEMBER_INTERVAL_LOG select "interval_log_id" , "member_id" ,"interval_type","interval_remark","interval_history" ,"last_interval" , "effect_time" ,
  "create_time","relation_id" , "orelation_id" ,"store_id" ,"enterprise_id", "interval_inout", "interval_status","interval_effect" ,
  "opt_status" ,"operator_id","update_time" ,"p_member_integral_code", "p_member_integral_name" , "member_integral_code" ,"member_integral_name" 
  "remark" , "frozen_status" ,"unfreeze_time" ,"effect_limit_date" ,"syc_erp_status" , "syc_erp_time","main_store_id" 
  "open_store_id" ,"main_part_store_id" ,"clique_id" ,"clique_member_id"
 from "tab_gic_member_interval_log"@mysql  ;
 
 select COUNT(*) as rc INTO RECNUM from TAB_GIC_MEMBER_INTERVAL_LOG  ;
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('TAB_GIC_MEMBER_INTERVAL_LOG', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('TAB_GIC_MEMBER_INTERVAL_LOG', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  update_time no ok
 end;
 --************************************************************
 PROCEDURE ETL_PAC_MEMBER_PERSONAL(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_MEMBER_PERSONAL ;
 insert into CRM_TAB_GIC_MEMBER_PERSONAL select * from "tab_gic_member_personal"@mysql  ;
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_MEMBER_PERSONAL  ;
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_MEMBER_PERSONAL', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_MEMBER_PERSONAL', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
 
  PROCEDURE ETL_PAC_MEMBER_REMARKS(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_MEMBER_REMARKS ;
 insert into CRM_TAB_GIC_MEMBER_REMARKS select * from "tab_gic_member_remarks"@mysql ;
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_MEMBER_REMARKS  ;
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_MEMBER_REMARKS', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_MEMBER_REMARKS', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
 
  PROCEDURE ETL_PAC_MEMBER_TAGS_RELATION(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM TAB_GIC_MEMBER_TAGS_RELATION ;
 insert into TAB_GIC_MEMBER_TAGS_RELATION select * from "tab_gic_member_tags_relation"@mysql; 
 select COUNT(*) as rc INTO RECNUM from TAB_GIC_MEMBER_TAGS_RELATION ;
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('TAB_GIC_MEMBER_TAGS_RELATION', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('TAB_GIC_MEMBER_TAGS_RELATION', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
 
  PROCEDURE ETL_PAC_TAGS(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM CRM_TAB_GIC_TAGS ;
 insert into CRM_TAB_GIC_TAGS select * from "tab_gic_tags"@mysql  ;
 select COUNT(*) as rc INTO RECNUM from CRM_TAB_GIC_TAGS ; 
        
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('CRM_TAB_GIC_TAGS', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('CRM_TAB_GIC_TAGS', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
 
  PROCEDURE ETL_PAC_ERP_ORDER(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM POS_TAB_ERP_ORDER ;
 insert into POS_TAB_ERP_ORDER select  "CardNo","StoreCode","StoreName","FacoryCode","SalerCode","SalerName","Clerkcode","OrderStatus","OrderTime","ReceiptsTime","OrderSerial",
"OorderSerial","RorderSerial","PPrice","APrice","RPayInfo","RPrice","RebatePrice","CouponCode","Remark","CreateTime","UpdateTime","Status" 
 from "TAB_ERP_ORDER"@mssql  ;
 
 select COUNT(*) as rc INTO RECNUM from POS_TAB_ERP_ORDER  ;
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('POS_TAB_ERP_ORDER', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('POS_TAB_ERP_ORDER', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
 
---*****************************************
PROCEDURE ETL_PAC_ERP_ORDER_ITEM(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM POS_TAB_ERP_ORDER_ITEM ;
 insert into POS_TAB_ERP_ORDER_ITEM select * from "TAB_ERP_ORDER_ITEM"@mssql  ;
 select COUNT(*) as rc INTO RECNUM from POS_TAB_ERP_ORDER_ITEM ;
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('POS_TAB_ERP_ORDER_ITEM', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('POS_TAB_ERP_ORDER_ITEM', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
 
/* ---*****************************************
PROCEDURE ETL_PAC_POS_SALES_ITEM(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM pos_saled02; --where "EXITDATE"=to_char(PIDATE,'yyyymmdd');
/* insert into pos_saled02 select "PLANT" as SHPCODE,"/BIC/ZP_DJBH" as DOCNUM,"/BIC/ZP_HH" as LINENUM,"MATERIAL" as SKU,"/BIC/ZSN" as ITEMCODE,
"/BIC/ZP_YWRQ" as EXITDATE,"/BIC/ZPLT_KEY" as ZPLT_KEY,"CALMONTH2" as CALMONTH2,"CALMONTH" as CALMONTH,"CALYEAR" as CALYEAR,
"/BIC/ZP_DGBM" as EMPCODE,"/BIC/ZP_KPM" as INVOICECODE,"/BIC/ZP_TCFKPM" as INVOICECODE1,"/BIC/ZP_THLX" as RETURNTYPE,"/BIC/ZP_XGRQ" as LASTDATE,
"/BIC/ZP_XSLX" as SOURCETYPE,"/BIC/ZP_YDH" as SOURCENUM,"/BIC/ZP_YWLX" as PRICETYPE,"/BIC/ZP_YJMC" as REMAINNAME,"/BIC/ZP_SL" as QTY1,
"/BIC/ZP_JF" as POINT,"/BIC/ZP_JHJ" as COST,"/BIC/ZP_JJKJ" as GOLDNUM,"/BIC/ZP_KYJF" as USEPOINT,"/BIC/ZP_KYYY" as USEBALANCE,"/BIC/ZP_YH" as EARNEST,
"/BIC/ZP_YY" as BALANCE,"/BIC/ZP_ZJJF" as ADDPOINT,"/BIC/ZP_ZL" as WEIGHT,"/BIC/ZP_ZQJ" as MARKEDPRICE,"/BIC/ZP_BDSYJF" as USEDPOINT,
"/BIC/ZP_CJGF" as DONEFEE,"/BIC/ZP_CJJE" as LINETOTAL,"/BIC/ZP_CJPJ" as DAYPRICE2,"/BIC/ZP_DRPJ" as DAYPRICE1,"/BIC/ZP_DXJE" as FORCASH,
"/BIC/ZP_GFZK" as DISCOUNT1,"/BIC/ZP_HYHL" as MEMWHALEY,"/BIC/ZP_HYQ" as MEMCOUPOS,"/BIC/ZP_KLHJE" as FEETOTAL,"/BIC/ZP_MDWXCB" as STORECOST,
"/BIC/ZP_MFQ" as COUPONS,"/BIC/ZP_SCJE" as SYSCOST,"/BIC/ZP_SCSQ" as MALLSTAMPS,"/BIC/ZP_SSS" as STONENUM,"/BIC/ZP_WXHZL" as AFTERWEIGHT,
"/BIC/ZP_WXQZL" as BEFOREWEIGHT,"/BIC/ZP_XSDJ" as PRICE,"/BIC/ZP_YJSL" as REMAINQTY,"/BIC/ZP_YJZL" as REMAINWEIGHT,"/BIC/ZP_ZK" as DISCOUNT,
"/BIC/ZP_ZKJE" as DISCOUNTPRICE,"STOR_LOC" as LOCCOD,"/BIC/ZP_DJRQ" as DOCDATE,"/BIC/ZP_KPMKL" as FEE,"/BIC/ZP_INSIDE" as ISINSIDE,
"/BIC/ZHTBH" as ZHTBH,"/BIC/ZP_BDMS" as ZP_BDMS,"/BIC/ZP_KPMDL" as TYPE,"/BIC/ZP_DZFZR" as SALEMAKER,"/BIC/ZDL" as ZDL,"/BIC/ZVKBUR" as ZVKBUR,
"/BIC/ZPOS_NGJE" as ZNGJE,"/BIC/ZPOS_DJJE" as ZDJJE,"/BIC/ZPOS_HBZ" as MEMO,"/BIC/ZPOS_HJXS" as ZPOS_HJXS,"/BIC/ZPOS_FHXS" as ZPOS_FHXS,
"/BIC/ZPOS_KE" as ZPOS_KE,"/BIC/ZPOS_ZQFY" as ZPOS_ZQFY,"/BIC/ZPOS_XSZE" as ZPOS_XSZE,"/BIC/ZPOS_SJJE" as ZPOS_SJJE,"/BIC/ZPOS_JSR" as ZPOS_JSR,
"/BIC/ZPOS_SR" as ZPOS_SR,"/BIC/ZP_YSPBM" as ZP_YSPBM,"/BIC/ZXSGF" as ZXSGF,"/BIC/ZCKSGJXS" as ZCKSGJXS,"/BIC/ZJMJSFSCS" as ZJMJSFSCS,
"/BIC/ZTCBZ" as ZTCBZ,"/BIC/ZADM_COST" as ZADM_COST,"/BIC/ZPUR_COST" as ZPUR_COST,"/BIC/ZISS_COST" as ZISS_COST,"/BIC/ZGRO_COST" as ZGRO_COST,
"/BIC/ZOTH_COST" as ZOTH_COST,"/BIC/ZREC_COST" as ZREC_COST,"/BIC/ZSAL_COST" as ZSAL_COST,"/BIC/ZSTO_COST" as ZSTO_COST,"/BIC/ZP_SGJTZH" as ZP_SGJTZH,
"/BIC/ZP_SGJCJH" as ZP_SGJCJH,"/BIC/ZKDDH" as ZKDDH,"/BIC/ZK_SGJCJ" as ZK_SGJCJ,"/BIC/ZK_SGJTZ" as ZK_SGJTZ,"COMP_CODE" as COMP_CODE,
"/BIC/ZKCQTY" as ZKCQTY,"BASE_UOM" as BASE_UOM,"/BIC/ZC_JLDW" as ZC_JLDW,"/BIC/ZC_FIRIP" as ZC_FIRIP,"/BIC/ZC_LASTIP" as ZC_LASTIP,
"/BIC/ZC_CGFS" as ZC_CGFS,"/BIC/ZC_RKRQ" as ZC_RKRQ,"VENDOR" as VENDOR,"/BIC/ZC_ISOLD" as ZC_ISOLD ,"CusPhone" as CusPhone
from "ZBW_HISSALES_PHONE"@Oldpos; -- where "/BIC/ZP_YWRQ"=to_char(PIDATE,'yyyymmdd'); */
/*  insert into pos_saled02  select "PLANT" as SHPCODE,replace(ltrim(replace("/BIC/ZP_DJBH",'0',' ')),' ','0') as DOCNUM,replace(ltrim(replace("/BIC/ZP_HH",'0',' ')),' ','0') as LINENUM,
      replace(ltrim(replace("MATERIAL",'0',' ')),' ','0') as SKU,replace(ltrim(replace("/BIC/ZSN",'0',' ')),' ','0') as ITEMCODE,
      "/BIC/ZP_YWRQ" as EXITDATE,"/BIC/ZPLT_KEY" as ZPLT_KEY,"CALMONTH2" as CALMONTH2,"CALMONTH" as CALMONTH,"CALYEAR" as CALYEAR,
      "/BIC/ZP_DGBM" as EMPCODE,"/BIC/ZP_KPM" as INVOICECODE,"/BIC/ZP_TCFKPM" as INVOICECODE1,"/BIC/ZP_THLX" as RETURNTYPE,"/BIC/ZP_XGRQ" as LASTDATE,
      replace(ltrim(replace("/BIC/ZP_XSLX",'0',' ')),' ','0') as SOURCETYPE,"/BIC/ZP_YDH" as SOURCENUM,"/BIC/ZP_YWLX" as PRICETYPE,"/BIC/ZP_YJMC" as REMAINNAME,"/BIC/ZP_SL" as QTY1,
      "/BIC/ZP_JF" as POINT,"/BIC/ZP_JHJ" as COST,"/BIC/ZP_JJKJ" as GOLDNUM,"/BIC/ZP_KYJF" as USEPOINT,"/BIC/ZP_KYYY" as USEBALANCE,"/BIC/ZP_YH" as EARNEST,
      "/BIC/ZP_YY" as BALANCE,"/BIC/ZP_ZJJF" as ADDPOINT,"/BIC/ZP_ZL" as WEIGHT,"/BIC/ZP_ZQJ" as MARKEDPRICE,"/BIC/ZP_BDSYJF" as USEDPOINT,
      "/BIC/ZP_CJGF" as DONEFEE,"/BIC/ZP_CJJE" as LINETOTAL,"/BIC/ZP_CJPJ" as DAYPRICE2,"/BIC/ZP_DRPJ" as DAYPRICE1,"/BIC/ZP_DXJE" as FORCASH,
      "/BIC/ZP_GFZK" as DISCOUNT1,"/BIC/ZP_HYHL" as MEMWHALEY,"/BIC/ZP_HYQ" as MEMCOUPOS,"/BIC/ZP_KLHJE" as FEETOTAL,"/BIC/ZP_MDWXCB" as STORECOST,
      "/BIC/ZP_MFQ" as COUPONS,"/BIC/ZP_SCJE" as SYSCOST,"/BIC/ZP_SCSQ" as MALLSTAMPS,"/BIC/ZP_SSS" as STONENUM,"/BIC/ZP_WXHZL" as AFTERWEIGHT,
      "/BIC/ZP_WXQZL" as BEFOREWEIGHT,"/BIC/ZP_XSDJ" as PRICE,"/BIC/ZP_YJSL" as REMAINQTY,"/BIC/ZP_YJZL" as REMAINWEIGHT,"/BIC/ZP_ZK" as DISCOUNT,
      "/BIC/ZP_ZKJE" as DISCOUNTPRICE,"STOR_LOC" as LOCCOD,"/BIC/ZP_DJRQ" as DOCDATE,"/BIC/ZP_KPMKL" as FEE,"/BIC/ZP_INSIDE" as ISINSIDE,
      "/BIC/ZHTBH" as ZHTBH,"/BIC/ZP_BDMS" as ZP_BDMS,"/BIC/ZP_KPMDL" as TYPE,"/BIC/ZP_DZFZR" as SALEMAKER,
      case when "/BIC/ZDL"='0000000001' then '铂金' when "/BIC/ZDL"='0000000002' then '非黄' when "/BIC/ZDL"='0000000003' then '黄金' 
           when "/BIC/ZDL"='0000000005' then '旧货' when "/BIC/ZDL"='0000000006' then '旧料' else '其他' end as ZDL,
      "/BIC/ZVKBUR" as ZVKBUR,
      "/BIC/ZPOS_NGJE" as ZNGJE,"/BIC/ZPOS_DJJE" as ZDJJE,"/BIC/ZPOS_HBZ" as MEMO,"/BIC/ZPOS_HJXS" as ZPOS_HJXS,"/BIC/ZPOS_FHXS" as ZPOS_FHXS,
      "/BIC/ZPOS_KE" as ZPOS_KE,"/BIC/ZPOS_ZQFY" as ZPOS_ZQFY,"/BIC/ZPOS_XSZE" as ZPOS_XSZE,"/BIC/ZPOS_SJJE" as ZPOS_SJJE,"/BIC/ZPOS_JSR" as ZPOS_JSR,
      "/BIC/ZPOS_SR" as ZPOS_SR,"/BIC/ZP_YSPBM" as ZP_YSPBM,"/BIC/ZXSGF" as ZXSGF,"/BIC/ZCKSGJXS" as ZCKSGJXS,"/BIC/ZJMJSFSCS" as ZJMJSFSCS,
      "/BIC/ZTCBZ" as ZTCBZ,"/BIC/ZADM_COST" as ZADM_COST,"/BIC/ZPUR_COST" as ZPUR_COST,"/BIC/ZISS_COST" as ZISS_COST,"/BIC/ZGRO_COST" as ZGRO_COST,
      "/BIC/ZOTH_COST" as ZOTH_COST,"/BIC/ZREC_COST" as ZREC_COST,"/BIC/ZSAL_COST" as ZSAL_COST,"/BIC/ZSTO_COST" as ZSTO_COST,"/BIC/ZP_SGJTZH" as ZP_SGJTZH,
      "/BIC/ZP_SGJCJH" as ZP_SGJCJH,"/BIC/ZKDDH" as ZKDDH,"/BIC/ZK_SGJCJ" as ZK_SGJCJ,"/BIC/ZK_SGJTZ" as ZK_SGJTZ,"COMP_CODE" as COMP_CODE,
      "/BIC/ZKCQTY" as ZKCQTY,"BASE_UOM" as BASE_UOM,"/BIC/ZC_JLDW" as ZC_JLDW,"/BIC/ZC_FIRIP" as ZC_FIRIP,"/BIC/ZC_LASTIP" as ZC_LASTIP,
      "/BIC/ZC_CGFS" as ZC_CGFS,"/BIC/ZC_RKRQ" as ZC_RKRQ,"VENDOR" as VENDOR,"/BIC/ZC_ISOLD" as ZC_ISOLD, "CusPhone" as CusPhone，
      '             ' as EJFL1,--二级分类
      to_char(d.FNAME) AS SKU_NAME1,--SKU名字
      to_char(d.FNAME) AS FSKU_NAME,--SN名字
      MDE.FNAME as FNAME_MD,          --门店名 
      TO_CHAR(MDE.FA002_NAME) AS FQY,--区域
      TO_CHAR(MDE.FA029_NAME) AS FQZ,--区总
      TO_CHAR(MDE.FA030_NAME) AS FQJ,--区经
      case when a."empName" is null then TO_CHAR(SP.FNAME) else a."empName" end AS FOPOR,  --业绩人
      MDE.FA023_NAME AS FATT_MD  --门店属性
from "ZBW_HISSALES_PHONE"@Oldpos a 
     LEFT JOIN BN_SYS_ORG_INFO MDE ON MDE.Fcode=a."PLANT" 
     LEFT JOIN BN_BIZ_SKU d on replace(ltrim(replace(a."/BIC/ZSN",'0',' ')),' ','0')=d.FCODE  --取SKU
     left join BN_BIZ_SA_MA x on x.fcode=replace(ltrim(replace(a."/BIC/ZP_DJBH",'0',' ')),' ','0')
     LEFT JOIN BN_BIZ_SA_SP SP ON x.FMID=SP.FPID AND SUBSTR(SP.FINDEX,2,1)=1;


 select COUNT(*) as rc INTO RECNUM from pos_saled02;-- where "EXITDATE"=to_char(PIDATE,'yyyymmdd');
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('POS_SALED02', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('POS_SALED02', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
 
PROCEDURE ETL_PAC_SKU_ATTRIB(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM sap_skuatt ;
 insert into sap_skuatt select * from "ZBW_SKU"@Oldpos  ;
 select COUNT(*) as rc INTO RECNUM from sap_skuatt ;
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('sap_skuatt', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('sap_skuatt', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
 */
 PROCEDURE ETL_PAC_TOTAL AS 
 PIDATE date;  
 BEGIN
  PIDATE := TRUNC(SYSDATE-1);
  ETL_PAC_STORE(PIDATE );
  ETL_PAC_CLERK(PIDATE  );
  ETL_PAC_COUP_CARD(PIDATE  );
  ETL_PAC_COUP_CARD_LOG(PIDATE );
  ETL_PAC_EVALUATE_MSG_LOG(PIDATE  );
  ETL_PAC_MEMBER(PIDATE  );
  ETL_PAC_MEMBER_CLERK(PIDATE  );
  ETL_PAC_MEMBER_FIELD_VALUE(PIDATE  );
  ETL_PAC_MEMBER_INFO(PIDATE  );
  ETL_PAC_MEMBER_INTERVAL_LOG(PIDATE );
  ETL_PAC_MEMBER_PERSONAL(PIDATE );
  ETL_PAC_MEMBER_REMARKS(PIDATE );
  ETL_PAC_MEMBER_TAGS_RELATION(PIDATE );
  ETL_PAC_TAGS(PIDATE );
--  ETL_PAC_POS_SALES_ITEM(PIDATE);
--  ETL_PAC_SKU_ATTRIB(PIDATE);
 -- ETL_PAC_ERP_ORDER(PIDATE );
 -- ETL_PAC_ERP_ORDER_ITEM(PIDATE );
 
 
   END;
  
end ETL_CRM_TOTALDATA;
/

