create view ZBW_POSSALES_CRM_MAIN as
  SELECT to_char(a.phone_no) as cardno,a.SHPCODE,to_char(a.DOCNUM) as DOCNUM,a.EXITDATE as EXITDATE,to_char(replace(ltrim(replace(a.sku,'0',' ')),' ','0')) as SKU,
       a.ITEMCODE,a.PRICETYPE,FOPOR,
       case when a.SOURCETYPE='1' then 0-a.QTY1 else a.QTY1 end as QTY1,  --数量
       case when a.SOURCETYPE='1' then 0-a.MARKEDPRICE else a.MARKEDPRICE end as MARKEDPRICE, --上柜价（折前价）
       case when a.SOURCETYPE='1' then 0-a.LINETOTAL else a.LINETOTAL end as LINETOTAL,       --成交金额
       case when a.SOURCETYPE='1' then 0-a.FEETOTAL else a.FEETOTAL end as FEETOTAL,          --商城回款（扣率后金额）
       case when a.SOURCETYPE='1' then 0-a.SYSCOST else a.SYSCOST end as SYSCOST             --商场金额+商场收券
FROM ZBW_POSSALES_CRM01 a
WHERE a.ISINSIDE=0 AND a.EXITDATE>='20180724' and a.LOCCODE<>'0009'
union all
SELECT to_char(a.cusphone) as cardno,to_char(a.SHPCODE) as SHPCODE,to_char(a.DOCNUM),to_char(a.EXITDATE),to_char(replace(ltrim(replace(a.sku,'0',' ')),' ','0')),
       to_char(a.ITEMCODE),to_char(a.PRICETYPE),FOPOR,
       QTY1,        --数量
       MARKEDPRICE, --上柜价（折前价）
       LINETOTAL,   --成交金额
       FEETOTAL,    --商城回款（扣率后金额）
       SYSCOST      --商场金额+商场收券
FROM POS_SALED02 a
WHERE a.PRICETYPE in('销售','退货','旧货','截金','套装') AND a.EXITDATE<'20180724' and a.ISINSIDE=0 and a.LOCCOD<>'0009'
/

