create view ZCRM_R010 as
  SELECT "订单号",单品销售金额,"订单日期","月","分类","区域" 
FROM
(
    SELECT ord."CardNo",a."OrderSerial" AS 订单号 ,NVL(a."rPrice",0) as 单品销售金额,TO_CHAR(ord."ReceiptsTime",'YYYY-MM') AS 订单日期,TO_CHAR(ord."ReceiptsTime",'MM') AS 月,FUN_SPLIT_ONE(d.FPROPERTY_VALUE,'/',6) AS 分类 ,
    B.FA002_NAME as 区域
    FROM 
        POS_TAB_ERP_ORDER_ITEM a
        JOIN POS_TAB_ERP_ORDER ord ON a."OrderSerial" = ord."OrderSerial" 
        LEFT JOIN BN_BIZ_SKU d on a."GoodsNo" = d.FCODE 
        LEFT JOIN BN_SYS_ORG_INFO B ON a."StoreCode" = B.FPCODE
) C where (分类 = '黄金' or 分类 = '非黄' ) AND NVL(C."CardNo",-1) = '-1' AND NVL(单品销售金额,0) <> 0
/

