create view ZBW_CHECK_POS_SALES as
  select "日期","门店","POS小票数","BW小票数","POS商场金额","BW商场金额","小票数差异","金额差异"
from
(
  select 日期,门店,SUM(case when 来源='POS' then 小票行数 else 0 end) as POS小票数,SUM(case when 来源='BW' then 小票行数 else 0 end) as BW小票数,
         SUM(case when 来源='POS' then 商场金额 else 0 end) as POS商场金额,SUM(case when 来源='BW' then 商场金额 else 0 end) as BW商场金额,
         SUM(case when 来源='POS' then 小票行数 else 0-小票行数 end) as 小票数差异,SUM(case when 来源='POS' then 商场金额 else 0-商场金额 end) as 金额差异
  from(
        select to_char(a.EXITDATE) as 日期,to_char(a.SHPCODE) as 门店,'POS' as 来源,count(distinct a.DOCNUM) as 小票行数,
               sum(case when a.SOURCETYPE='1' then 0-a.SYSCOST else a.SYSCOST end) as "商场金额"
        from ZBW_POSSALES_NEW a
        where
              --to_char(to_date(a.EXITDATE,'yyyymmdd'),'yyyymm')=to_char(sysdate,'yyyymm') and a.EXITDATE<>to_char(sysdate,'yyyymmdd') and
              --to_char(to_date(a.EXITDATE,'yyyymmdd'),'yyyymmdd')='20181029' and
              a.FATT_MD not in('电商店-B2B','电商店-B2C') and to_char(a.LOCCODE)<>'0009' and a.ZDL not in('旧料','其他') and
              a.PRICETYPE in('销售','套装','退货','截金','旧货') and a.ISINSIDE<>1
        group by to_char(a.EXITDATE),to_char(a.SHPCODE)
        union all
        select to_char(a.EXITDATE) as 日期,to_char(a.SHPCODE) as 门店,'BW' as 来源,count(distinct a.DOCNUM) as 小票行数,
               sum(SYSCOST) as 商场金额
        from pos_saled02 a
        where
              --to_char(to_date(a.EXITDATE,'yyyymmdd'),'yyyymm')=to_char(sysdate,'yyyymm') and
              --to_char(to_date(a.EXITDATE,'yyyymmdd'),'yyyymmdd')='20181029' and
              a.FATT_MD not in('电商店-B2B','电商店-B2C') and to_char(a.LOCCOD)<>'0009' and a.ZDL not in('旧料','其他') and
              a.PRICETYPE in('销售','套装','退货','截金','旧货') and a.ISINSIDE<>1
        group by to_char(a.EXITDATE),to_char(a.SHPCODE)
  ) a
  group by 日期,门店
)
where (小票数差异<>0 OR 金额差异<>0) and abs(金额差异)>0.001
/

