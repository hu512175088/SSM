create view ZCRM_R006 as
  select yq.qy,yq.qj,to_char(yq.usedt,'yyyy-mm') as usedt,sum(yq.sysl) as sysl,sum(yq.sales) as sales,sum(yq.yfsl) as yfsl from
 (
select orn.fa002_name as qy ,orn.fa006_name as qj,clog."used_time" as usedt,count(*) as sysl,sum(od.sales) as sales ,0 as yfsl
from crm_tab_gic_coup_card_log clog
left join crm_tab_gic_coup_card card on  clog."card_id"=card."coup_card_id"
left join crm_tab_gic_member  mb  on clog."member_id"=mb."member_id"
left join (
select shpcode,cardno ,sum(syscost) as sales from zbw_possales_crm_main group by shpcode,cardno ) od on mb."card_num"=od.cardno
left join BN_SYS_ORG_INFO orn on od.shpcode=orn.fpcode
where clog."status"=5 and card."card_name" like'%生日%' and mb."card_num"<> '-1'
group by orn.fa002_name,orn.fa006_name,clog."used_time"
union all
select orn.fa002_name as qy,orn.fa006_name as qj,clog."receive_time" as usedt,0 as sysl,0 as sales,count(*) as yfsl from crm_tab_gic_coup_card_log  clog
left join crm_tab_gic_coup_card card on  clog."card_id"=card."coup_card_id"
left join crm_tab_gic_member mb on clog."member_id"=mb."member_id"
left join BN_SYS_ORG_INFO orn on mb."store_code"=orn.fpcode
where clog."status"=4 and card."card_name" like'%生日%' and mb."card_num"<> '-1'
group by orn.fa002_name,orn.fa006_name,clog."receive_time"  ) yq
group by yq.qy,yq.qj,to_char(yq.usedt,'yyyy-mm')
/

