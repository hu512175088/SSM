create view ZBW_POSSALES_MAIN_NEW_TEST as
  SELECT a.FQY as "销售区域",a.FQZ as "区总",a.FQJ as "区经",to_char(a.SHPCODE) as "门店代码",to_char(a.FNAME_MD) as "门店名称",to_char(a.FATT_MD) as "门店属性",a.ZDL as "商品大类",a.EJFL1 as "二级分类",
       to_char(a.DOCNUM) as "小票号",to_char(a.LINENUM) as "小票行号",a.EXITDATE as "过账日期",to_char(a.SKU) as "SKU",to_char(a.SKU_NAME1) as "SKU名",to_char(a.ITEMCODE) as "批次编码",to_char(a.FSKU_NAME) as "批次名称",
       to_char(a.DOCDATE) as "单据创建日期",to_char(a.INVOICECODE) as "开票码",to_char(a.SOURCETYPE) as "小票类型",to_char(a.MAKER) as "制单人工号",to_char(a.FOPOR) as "业绩归属人",
       case when a.SOURCETYPE='1' then 0-a.QTY1 else a.QTY1 end as "数量",  --数量
       case when a.SOURCETYPE='1' then 0-a.MARKEDPRICE else a.MARKEDPRICE end as "上柜价", --上柜价（折前价）
       to_char(a.PRICETYPE) as "小票行类型",
       case when a.SOURCETYPE='1' then 1-a.LINETOTAL else a.LINETOTAL end  as "成交金额",       --成交金额
       case when a.SOURCETYPE='1' then 0-a.FEETOTAL else a.FEETOTAL end as "商城回款",          --商城回款（扣率后金额）
       case when a.SOURCETYPE='1' then 0-a.SYSCOST else a.SYSCOST end as "商场金额",             --商场金额+商场收券
       case when a.SOURCETYPE='1' then 0-a.PRICE else a.PRICE end as "销售单价",             --销售单价
       to_char(a.LOCCODE) as "库存地点",a.FEE as "开票码扣率",to_char(a.ISINSIDE) as "是否内购"
FROM ZBW_POSSALES_NEW a
where a.EXITDATE>'20180731' and a.FATT_MD not in('电商店-B2B','电商店-B2C') and to_char(a.LOCCODE)<>'0009' and
      a.ZDL not in('旧料','其他') and a.PRICETYPE in('销售','套装','退货','截金','旧货') and a.ISINSIDE<>1
union all
SELECT a.FQY as "销售区域",a.FQZ as "区总",a.FQJ as "区经",to_char(a.SHPCODE) as "门店代码",to_char(a.FNAME_MD) as "门店名称",to_char(a.FATT_MD) as "门店属性",a.ZDL as "商品大类",a.EJFL1 as "二级分类",
       to_char(a.DOCNUM) as "小票号",to_char(a.LINENUM) as "小票行号",to_char(a.EXITDATE) as "过账日期",to_char(a.SKU) as "SKU",to_char(a.SKU_NAME1) as "SKU名",to_char(a.ITEMCODE) as "批次编码",a.FSKU_NAME as "批次名称",
       to_char(a.DOCDATE) as "单据创建日期",to_char(a.INVOICECODE) as "开票码",to_char(a.SOURCETYPE) as "小票类型",to_char(a.SALEMAKER) as "制单人工号",to_char(a.empcode) as "业绩归属人",
       a.QTY1 as "数量",  --数量
       a.MARKEDPRICE as "上柜价", --上柜价（折前价）
       to_char(a.PRICETYPE) as "小票行类型",
       a.LINETOTAL as "成交金额",       --成交金额
       a.FEETOTAL as "商城回款",          --商城回款（扣率后金额）
       a.SYSCOST as "商场金额",             --商场金额+商场收券
       a.PRICE as "销售单价",             --销售单价
       to_char(a.LOCCOD) as "库存地点",a.FEE as "开票码扣率",to_char(a.ISINSIDE) as "是否内购"
FROM pos_saled02 a
where a.EXITDATE<='20180731' and a.FATT_MD not in('电商店-B2B','电商店-B2C') and to_char(a.LOCCOD)<>'0009' and
      a.ZDL not in('旧料','其他') and a.PRICETYPE in('销售','套装','退货','截金','旧货') and a.ISINSIDE<>1
/

