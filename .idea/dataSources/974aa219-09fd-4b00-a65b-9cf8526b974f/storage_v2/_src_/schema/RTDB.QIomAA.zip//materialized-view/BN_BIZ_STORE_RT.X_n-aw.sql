create materialized view BN_BIZ_STORE_RT
refresh complete on demand
  as
    select  SHPCODE,SKU,ITEMCODE,LOCCODE,QTY1 from (
 select substr(forg_store_code,1,4) as SHPCODE,fspu_id as sku,substr(forg_store_code,5,4) as LOCCODE ,fsku_code as ITEMCODE ,sum(fqty_base) as QTY1
 from  bn_biz_store a left join BN_BIZ_SKU b on a.fsku_code=b.fcode
 group by substr(forg_store_code,1,4) ,substr(forg_store_code,5,4),fspu_id,fsku_code )
 where qty1 >0
/

