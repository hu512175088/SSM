create view ZCRM_R003 as
  SELECT 会员号,单号,订单日期,年龄,标签 FROM ( 
  SELECT 
    C."phone_number" AS 会员号,
    ord."OrderSerial" AS 单号,
    --ord."ReceiptsTime" AS 订单日期,
    TO_CHAR(ord."ReceiptsTime",'YYYY-MM') AS 订单日期,
    FUN_SPLIT_ONE(d.FPROPERTY_VALUE,'/',6) AS 分类,
    d.FSPU_ID AS SKU码,
    d.FNAME AS 产品名称,
    FUN_SPLIT_ONE(d.FPROPERTY_VALUE,'/',10)||FUN_SPLIT_ONE(d.FPROPERTY_VALUE,'/',16) AS 产品属性 ,
    C.NUM_AGE as 年龄,
    E."tags_name" as 标签
    FROM 
        (SELECT * FROM POS_TAB_ERP_ORDER WHERE POS_TAB_ERP_ORDER."RPrice" > '0') ord
        JOIN POS_TAB_ERP_ORDER_ITEM a ON a."OrderSerial" = ord."OrderSerial" 
        LEFT JOIN BN_BIZ_SKU d ON a."GoodsNo" = d.FCODE 
        LEFT JOIN 
            (SELECT "phone_number","member_personal_id","member_id",(TO_CHAR(SYSDATE,'YYYY')-TO_CHAR("member_birthday",'YYYY')) AS NUM_AGE 
                FROM 
                    crm_tab_gic_member_personal 
                WHERE "member_birthday" IS NOT NULL 
                ) C
            ON ord."CardNo" = C."phone_number"
        left JOIN tab_gic_member_tags_relation E ON E."member_id" = C."member_id"
WHERE NVL(ord."CardNo",-1) > '-1'
)
WHERE 分类 = '非黄' OR 分类 = '黄金'
/

