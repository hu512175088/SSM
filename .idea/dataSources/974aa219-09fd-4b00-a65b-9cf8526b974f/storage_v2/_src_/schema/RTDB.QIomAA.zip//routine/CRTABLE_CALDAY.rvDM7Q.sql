create procedure CRTABLE_CALDAY(PIDATE IN DATE ) is
  VDATE date; 
  EDATE date; 
  begin
  vDATE := TRUNC(PIDATE);
  edate := to_date('2036-01-01','yyyy-mm-dd');
  delete from  calday;
  while vDATE < edate loop
  insert into calday 
  select trunc(vDATE) as vdate,to_char(vDATE,'yyyy') as vyear ,to_char(vDATE,'mm') as vmonth,to_char(vDATE,'day','NLS_DATE_LANGUAGE=''SIMPLIFIED CHINESE''') as vweek,
  TO_CHAR(vDATE, 'WW') as vwweknum,
  to_char(TRUNC(TO_DATE(to_char(vDATE,'yyyy-MM-dd'),'yyyy-MM-dd'),'IW'),'yyyy-MM-dd')  as weekstr,
  to_char(TRUNC(TO_DATE(to_char(vDATE,'yyyy-MM-dd'),'YYYY-MM-DD'),'IW') + 6,'yyyy-MM-dd') as weekend
   from dual;
   commit;
   vDATE:= vDATE + 1;
     
  end loop; 
    
 
end CRTABLE_CALDAY;
/

