create view ZBW_POSSALES_MAIN_NGXS as
  select a."过账日期",a."SKU",a."库存地点",a."门店代码",a."一级分类",a."二级分类",a."规格",a."规格名",a."销售数量",a."商场金额",c.QTY1 as 库存
from
(
  SELECT a.过账日期,a.SKU,a.库存地点,a.门店代码,b.一级分类,b.二级分类,b.规格,b."规格名",SUM(a.数量) AS 销售数量,"SUM"(a.商场金额) AS 商场金额--,SUM(c.QTY1) AS 库存
  FROM ZBW_POSSALES_MAIN_NEW a
  LEFT JOIN ZBW_SKU b ON a.SKU = b.SKU
  WHERE a.库存地点='0003' AND a.门店代码 IN ('5085','5492','5169','5136') and
        a.过账日期>='20181113'
  GROUP BY a.过账日期,a.库存地点,a.门店代码,b.一级分类,b.二级分类,b.规格,b."规格名",a.SKU
) a
LEFT join
     (select SHPCODE,LOCCODE,sku,sum(qty1) as qty1
        from zbw_store x
        where x.SHPCODE in('5085','5492','5169','5136') and x.LOCCODE='0003' group by SHPCODE,LOCCODE,sku) c ON a.门店代码=c.SHPCODE and a.库存地点=c.LOCCODE and a.SKU = c.SKU
order by 一级分类,二级分类,a.商场金额
/

