create package body ETL_BW_SALES is
 VMSG    VARCHAR2(255);

 PROCEDURE ETL_PAC_POS_SALES_ITEM(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM pos_saled02; 
  insert into pos_saled02  select "PLANT" as SHPCODE,replace(ltrim(replace("/BIC/ZP_DJBH",'0',' ')),' ','0') as DOCNUM,replace(ltrim(replace("/BIC/ZP_HH",'0',' ')),' ','0') as LINENUM,
      replace(ltrim(replace("MATERIAL",'0',' ')),' ','0') as SKU,replace(ltrim(replace("/BIC/ZSN",'0',' ')),' ','0') as ITEMCODE,
      "/BIC/ZP_YWRQ" as EXITDATE,"/BIC/ZPLT_KEY" as ZPLT_KEY,"CALMONTH2" as CALMONTH2,"CALMONTH" as CALMONTH,"CALYEAR" as CALYEAR,
      "/BIC/ZP_DGBM" as EMPCODE,"/BIC/ZP_KPM" as INVOICECODE,"/BIC/ZP_TCFKPM" as INVOICECODE1,"/BIC/ZP_THLX" as RETURNTYPE,"/BIC/ZP_XGRQ" as LASTDATE,
      replace(ltrim(replace("/BIC/ZP_XSLX",'0',' ')),' ','0') as SOURCETYPE,"/BIC/ZP_YDH" as SOURCENUM,"/BIC/ZP_YWLX" as PRICETYPE,"/BIC/ZP_YJMC" as REMAINNAME,"/BIC/ZP_SL" as QTY1,
      "/BIC/ZP_JF" as POINT,"/BIC/ZP_JHJ" as COST,"/BIC/ZP_JJKJ" as GOLDNUM,"/BIC/ZP_KYJF" as USEPOINT,"/BIC/ZP_KYYY" as USEBALANCE,"/BIC/ZP_YH" as EARNEST,
      "/BIC/ZP_YY" as BALANCE,"/BIC/ZP_ZJJF" as ADDPOINT,"/BIC/ZP_ZL" as WEIGHT,"/BIC/ZP_ZQJ" as MARKEDPRICE,"/BIC/ZP_BDSYJF" as USEDPOINT,
      "/BIC/ZP_CJGF" as DONEFEE,"/BIC/ZP_CJJE" as LINETOTAL,"/BIC/ZP_CJPJ" as DAYPRICE2,"/BIC/ZP_DRPJ" as DAYPRICE1,"/BIC/ZP_DXJE" as FORCASH,
      "/BIC/ZP_GFZK" as DISCOUNT1,"/BIC/ZP_HYHL" as MEMWHALEY,"/BIC/ZP_HYQ" as MEMCOUPOS,"/BIC/ZP_KLHJE" as FEETOTAL,"/BIC/ZP_MDWXCB" as STORECOST,
      "/BIC/ZP_MFQ" as COUPONS,"/BIC/ZP_SCJE" as SYSCOST,"/BIC/ZP_SCSQ" as MALLSTAMPS,"/BIC/ZP_SSS" as STONENUM,"/BIC/ZP_WXHZL" as AFTERWEIGHT,
      "/BIC/ZP_WXQZL" as BEFOREWEIGHT,"/BIC/ZP_XSDJ" as PRICE,"/BIC/ZP_YJSL" as REMAINQTY,"/BIC/ZP_YJZL" as REMAINWEIGHT,"/BIC/ZP_ZK" as DISCOUNT,
      "/BIC/ZP_ZKJE" as DISCOUNTPRICE,"STOR_LOC" as LOCCOD,"/BIC/ZP_DJRQ" as DOCDATE,"/BIC/ZP_KPMKL" as FEE,"/BIC/ZP_INSIDE" as ISINSIDE,
      "/BIC/ZHTBH" as ZHTBH,"/BIC/ZP_BDMS" as ZP_BDMS,"/BIC/ZP_KPMDL" as TYPE,"/BIC/ZP_DZFZR" as SALEMAKER,
      case when "/BIC/ZDL"='0000000001' then '铂金' when "/BIC/ZDL"='0000000002' then '非黄' when "/BIC/ZDL"='0000000003' then '黄金' 
           when "/BIC/ZDL"='0000000005' then '旧货' when "/BIC/ZDL"='0000000006' then '旧料' else '其他' end as ZDL,
      "/BIC/ZVKBUR" as ZVKBUR,
      "/BIC/ZPOS_NGJE" as ZNGJE,"/BIC/ZPOS_DJJE" as ZDJJE,"/BIC/ZPOS_HBZ" as MEMO,"/BIC/ZPOS_HJXS" as ZPOS_HJXS,"/BIC/ZPOS_FHXS" as ZPOS_FHXS,
      "/BIC/ZPOS_KE" as ZPOS_KE,"/BIC/ZPOS_ZQFY" as ZPOS_ZQFY,"/BIC/ZPOS_XSZE" as ZPOS_XSZE,"/BIC/ZPOS_SJJE" as ZPOS_SJJE,"/BIC/ZPOS_JSR" as ZPOS_JSR,
      "/BIC/ZPOS_SR" as ZPOS_SR,"/BIC/ZP_YSPBM" as ZP_YSPBM,"/BIC/ZXSGF" as ZXSGF,"/BIC/ZCKSGJXS" as ZCKSGJXS,"/BIC/ZJMJSFSCS" as ZJMJSFSCS,
      "/BIC/ZTCBZ" as ZTCBZ,"/BIC/ZADM_COST" as ZADM_COST,"/BIC/ZPUR_COST" as ZPUR_COST,"/BIC/ZISS_COST" as ZISS_COST,"/BIC/ZGRO_COST" as ZGRO_COST,
      "/BIC/ZOTH_COST" as ZOTH_COST,"/BIC/ZREC_COST" as ZREC_COST,"/BIC/ZSAL_COST" as ZSAL_COST,"/BIC/ZSTO_COST" as ZSTO_COST,"/BIC/ZP_SGJTZH" as ZP_SGJTZH,
      "/BIC/ZP_SGJCJH" as ZP_SGJCJH,"/BIC/ZKDDH" as ZKDDH,"/BIC/ZK_SGJCJ" as ZK_SGJCJ,"/BIC/ZK_SGJTZ" as ZK_SGJTZ,"COMP_CODE" as COMP_CODE,
      "/BIC/ZKCQTY" as ZKCQTY,"BASE_UOM" as BASE_UOM,"/BIC/ZC_JLDW" as ZC_JLDW,"/BIC/ZC_FIRIP" as ZC_FIRIP,"/BIC/ZC_LASTIP" as ZC_LASTIP,
      "/BIC/ZC_CGFS" as ZC_CGFS,"/BIC/ZC_RKRQ" as ZC_RKRQ,"VENDOR" as VENDOR,"/BIC/ZC_ISOLD" as ZC_ISOLD, "CusPhone" as CusPhone，
      '             ' as EJFL1,--二级分类
      to_char(d.FNAME) AS SKU_NAME1,--SKU名字
      to_char(d.FNAME) AS FSKU_NAME,--SN名字
      MDE.FNAME as FNAME_MD,          --门店名 
      TO_CHAR(MDE.FA002_NAME) AS FQY,--区域
      TO_CHAR(MDE.FA029_NAME) AS FQZ,--区总
      TO_CHAR(MDE.FA030_NAME) AS FQJ,--区经
      case when a."empName" is null then TO_CHAR(SP.FNAME) else a."empName" end AS FOPOR,  --业绩人
      MDE.FA023_NAME AS FATT_MD  --门店属性
from "ZBW_HISSALES_PHONE"@Oldpos a 
     LEFT JOIN BN_SYS_ORG_INFO MDE ON MDE.Fcode=a."PLANT" 
     LEFT JOIN BN_BIZ_SKU d on replace(ltrim(replace(a."/BIC/ZSN",'0',' ')),' ','0')=d.FCODE  --取SKU
     left join BN_BIZ_SA_MA x on x.fcode=replace(ltrim(replace(a."/BIC/ZP_DJBH",'0',' ')),' ','0')
     LEFT JOIN BN_BIZ_SA_SP SP ON x.FMID=SP.FPID AND SUBSTR(SP.FINDEX,2,1)=1;


 select COUNT(*) as rc INTO RECNUM from pos_saled02;-- where "EXITDATE"=to_char(PIDATE,'yyyymmdd');
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('POS_SALED02', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('POS_SALED02', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
 
PROCEDURE ETL_PAC_SKU_ATTRIB(PIDATE IN DATE ) AS 
 RECNUM INT;
 begin
 delete FROM sap_skuatt ;
 insert into sap_skuatt select * from "ZBW_SKU"@Oldpos  ;
 select COUNT(*) as rc INTO RECNUM from sap_skuatt ;
 insert into CRM_ETL_REC_LOG(TBNAME, ETDATE,RENUM, DBDATE, CNTENT)
        values ('sap_skuatt', sysdate,RECNUM, PIDATE, '');
 COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK ;
       VMSG := '错误号:' || SQLCODE || ',错误信息:' || SQLERRM;
        insert into CRM_ETL_LOG(TBNAME, ETDATE, DBDATE, CONTENT)
        values ('sap_skuatt', sysdate, PIDATE, substr('过程出错' || VMsg, 1, 255));
        commit;
   -------  
 end;
 
 PROCEDURE ETL_PAC_TOTAL AS 
 PIDATE date;  
 BEGIN
  PIDATE := TRUNC(SYSDATE-1);
  ETL_PAC_POS_SALES_ITEM(PIDATE);
  ETL_PAC_SKU_ATTRIB(PIDATE);

 
   END;
end ETL_BW_SALES;
/

