create view ZBW_POSSALES_CRM01 as
  SELECT case when a.Findex=11 then to_char(SUBSTR(a.Fde_Code,1,4)) when a.Findex=21 then to_char(SUBSTR(a.Fre_Code,1,4)) end AS SHPCODE,
       a.FCODE AS DOCNUM,b.FFID AS LINENUM,to_char(a.FBIZTIME,'yyyymmdd') AS EXITDATE,to_char(d.Fspu_Id) AS SKU,
       to_char(b.Fsku_Code) AS ITEMCODE,to_char(a.Fcreatetime,'yyyymmdd') AS DOCDATE,'NONE' AS ADSCENTRYS,'NONE' AS EMPCODE,'NONE' AS SALEMAKER,'NONE' AS RECHECK,
       'NONE' AS FEETYPE,'NONE' AS RDOCNUM,'NONE' AS CARDID,'NONE' AS CUSPHONE,'NONE' AS CUSCODE,'NONE' AS CUSNAME,to_char(b.Frate_Code) AS INVOICECODE,'NONE' AS ISNEED,'NONE' AS AUDIT1,
      'NONE'AS INVOICECODE1,'NONE' AS RETURNTYPE,'NONE' AS REPAIRADDRESS,to_char(a.Fupdatetime,'yyyymmdd') AS LASTDATE,
       case when a.Findex=11 then '0' when a.Findex=21 then '1' end AS SOURCETYPE,
       a.Fscode AS SOURCENUM,'NONE' AS AGRDELDATE,'NONE' AS REMAINNAME,a.Foperatorid AS MAKER,0 AS POINT1,0.00 AS COST1,0.00 AS GOLDNUM,0 AS USEPOINT,0.00 AS USEBALANCE,b.FQTY_BASE AS QTY1,
       0.00 AS EARNEST,0.00 AS BALANCE,0 AS ADDPOINT,0.00 AS WEIGHT,case when b.Fprice_Sale is null then b.Famount_Base else b.Fprice_Sale end AS MARKEDPRICE,
       case when c.FNAME='内购' then '内购' when b.fsku_code like'500000%' then '费用' when a.Findex=11 then '销售' when a.Findex=21 then '退货' end AS PRICETYPE,
      'NONE'AS HANDS,0 AS USEDPOINT,
       b.Famount_Base AS LINETOTAL,
       0.00 AS FORCASH,0.00 AS DISCOUNT1,0.00 AS MEMWHALEY,0.00 AS MEMCOUPOS,case when Frate_Value is null then b.Famount_Base else b.Famount_Base * (1-b.Frate_Value/100) end AS FEETOTAL,
       0.00 AS STORECOST,0.00 AS COUPONS,case when b.Fprice_Sale is null then b.Famount_Base when i.SPR_ZKJE2 is null then 0 else i.SPR_ZKJE2 end as SYSCOST,0.00 AS MALLSTAMPS,0.00 AS STONENUM,
       0.00 AS AFTERWEIGHT,0.00 AS BEFOREWEIGHT,b.Famount_Sale PRICE,0 AS REMAINQTY,0.00 AS REMAINWEIGHT,
       0.00 AS DISCOUNT,0.00 AS DISCOUNTPRICE,case when a.Findex=11 then to_char(SUBSTR(a.Fde_Code,5,4)) when a.Findex=21 then to_char(SUBSTR(a.Fre_Code,5,4)) end AS LOCCODE,
       case when Frate_Value is null then 0 else b.Frate_Value/100 end AS FEE,case when c.FNAME='内购' then 1 else 0 end AS ISINSIDE,
       '' AS TYPE1,b.fremark AS MEMO,a.fmid as FMID,a.ftrans_state as ftrans_state,to_char(a.ftrans_time,'yyyymmdd') as ftrans_time,
       a.fcid as phone_no,TO_CHAR(SP.FNAME) AS FOPOR
FROM  BN_BIZ_SA_DE b left join BN_BIZ_SA_MA a on A.FMID=B.FPID
                    left join (select distinct MA_FSID,Fname from zbw_pospay where Fname='内购') c on b.FPID=c.MA_FSID --判断内购
                    LEFT JOIN BN_BIZ_SA_SP SP ON a.FMID=SP.FPID AND SUBSTR(SP.FINDEX,2,1)=1
                    left join BN_BIZ_SKU d on b.Fsku_Code=d.FCODE  --取SKU
                    left join (select Y.FRID,sum(Y.famount_base) as SPR_ZKJE1,sum(Y.famount_sale) as SPR_ZKJE2,sum(Y.famount_discrate) as SPR_ZKJE3
                               from bn_biz_pay_spm Y
                               where Fname in('商场收银','商场收券','现金','银行卡','微信','支付宝','旧料旧货','定金','折旧费','内购')
                               group by Y.FRID) i on b.fmid=i.FRID --取商场金额
WHERE a.Fstate=50 and a.ftrans_state <> 99
union all
--销售（老POS业务类型：旧货）
SELECT case when a.Findex=11 then to_char(SUBSTR(a.Fde_Code,1,4)) when a.Findex=21 then to_char(SUBSTR(a.Fre_Code,1,4)) end AS SHPCODE,
       a.FCODE AS DOCNUM,b.ffid AS LINENUM,to_char(a.FBIZTIME,'yyyymmdd') AS EXITDATE,to_char(c.FSPU_ID) AS SKU,
       to_char(b.RE_FCODE) AS ITEMCODE,to_char(a.Fcreatetime,'yyyymmdd') AS DOCDATE,'NONE' AS ADSCENTRYS,'NONE' AS EMPCODE,'NONE' AS SALEMAKER,'NONE' AS RECHECK,
      'NONE'AS FEETYPE,'NONE' AS RDOCNUM,'NONE' AS CARDID,'NONE' AS CUSPHONE,'NONE' AS CUSCODE,'NONE' AS CUSNAME,'NONE' AS INVOICECODE,'NONE' AS ISNEED,'NONE' AS AUDIT1,
      'NONE'AS INVOICECODE1,'NONE' AS RETURNTYPE,'NONE' AS REPAIRADDRESS,to_char(a.Fupdatetime,'yyyymmdd') AS LASTDATE,
       case when a.Findex=11 then '0' when a.Findex=21 then '1' end AS SOURCETYPE,
       a.Fscode AS SOURCENUM,'NONE' AS AGRDELDATE,'NONE' AS REMAINNAME,a.Foperatorid AS MAKER,0 AS POINT1,0.00 AS COST1,0.00 AS GOLDNUM,0 AS USEPOINT,0.00 AS USEBALANCE,-1 AS QTY1,
       0.00 AS EARNEST,0.00 AS BALANCE,0 AS ADDPOINT,0 AS WEIGHT,0-b.RE_Famount_Base AS MARKEDPRICE,
       case when b.RE_FINDEX='10' then '旧料' when b.RE_FINDEX='20' then '旧货' when b.RE_FINDEX='21' then '旧料' end AS PRICETYPE,
      'NONE'AS HANDS,0 AS USEDPOINT,
       0-b.RE_Famount_Base AS LINETOTAL,0.00 AS FORCASH,0.00 AS DISCOUNT1,0.00 AS MEMWHALEY,0.00 AS MEMCOUPOS,0.00 AS FEETOTAL,
       0.00 AS STORECOST,0.00 AS COUPONS,0-b.Famount_sale AS SYSCOST,0.00 AS MALLSTAMPS,0.00 AS STONENUM,0.00 AS AFTERWEIGHT,0.00 AS BEFOREWEIGHT,0.00 AS PRICE,0 AS REMAINQTY,0.00 AS REMAINWEIGHT,
       0.00 AS DISCOUNT,0.00 AS DISCOUNTPRICE,'0001' AS LOCCODE,
       0 AS FEE,case when b.FNAME='内购' then 1 else 0 end AS ISINSIDE,'NONE' AS TYPE1,b.fremark AS MEMO,a.fmid as FMID,
       1 as ftrans_state,to_char('','yyyymmdd') as ftrans_time,a.fcid as phone_no,TO_CHAR(SP.FNAME) AS FOPOR
FROM ZBW_POSRETRIEVE b left join BN_BIZ_SA_MA a on a.fmid=b.MA_FSID
                       left join bn_biz_sku c on c.FCODE=b.RE_FCODE
                       LEFT JOIN BN_BIZ_SA_SP SP ON a.FMID=SP.FPID AND SUBSTR(SP.FINDEX,2,1)=1
WHERE a.Fstate=50 and a.ftrans_state <> 99 and b.FNAME='旧料旧货' and b.RE_FINDEX='20'
/

