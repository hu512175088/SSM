create view ZCRM_R001 as
  select to_char("card_giving_time",'yyyy-mm') as 年月,count("card_num") as 开卡人数,
 "SUBSTR"(to_char("card_giving_time",'yyyy-mm'), 6, 2) AS 月
from crm_tab_gic_member  
where "card_num" <> -1 and "store_code" not in('saler_E3','5274','5271')
group by to_char("card_giving_time",'yyyy-mm')
/

