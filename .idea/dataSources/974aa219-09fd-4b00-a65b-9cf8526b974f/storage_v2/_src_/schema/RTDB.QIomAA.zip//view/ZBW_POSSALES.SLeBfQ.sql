create view ZBW_POSSALES as
  SELECT case when a.Findex=11 then to_char(SUBSTR(a.Fde_Code,1,4)) when a.Findex=21 then to_char(SUBSTR(a.Fre_Code,1,4)) end AS SHPCODE,
       a.FCODE AS DOCNUM,b.FFID AS LINENUM,to_char(a.FBIZTIME,'yyyymmdd') AS EXITDATE,to_char(d.Fspu_Id) AS SKU,
       to_char(b.Fsku_Code) AS ITEMCODE,to_char(a.Fcreatetime,'yyyymmdd') AS DOCDATE,'NONE' AS ADSCENTRYS,'NONE' AS EMPCODE,'NONE' AS SALEMAKER,'NONE' AS RECHECK,
       'NONE' AS FEETYPE,'NONE' AS RDOCNUM,'NONE' AS CARDID,'NONE' AS CUSPHONE,'NONE' AS CUSCODE,'NONE' AS CUSNAME,to_char(b.Frate_Code) AS INVOICECODE,'NONE' AS ISNEED,'NONE' AS AUDIT1,
      'NONE'AS INVOICECODE1,'NONE' AS RETURNTYPE,'NONE' AS REPAIRADDRESS,to_char(a.Fupdatetime,'yyyymmdd') AS LASTDATE,
       case when a.Findex=11 then '0' when a.Findex=21 then '1' end AS SOURCETYPE,
       a.Fscode AS SOURCENUM,'NONE' AS AGRDELDATE,'NONE' AS REMAINNAME,a.Foperatorid AS MAKER,0 AS POINT1,0.00 AS COST1,0.00 AS GOLDNUM,0 AS USEPOINT,0.00 AS USEBALANCE,b.FQTY_BASE AS QTY1,
       0.00 AS EARNEST,0.00 AS BALANCE,0 AS ADDPOINT,0.00 AS WEIGHT,case when b.Fprice_Sale is null then b.Famount_Base else b.Fprice_Sale end AS MARKEDPRICE,
       case when c.FNAME='内购' then '内购' when b.fsku_code like'500000%' then '费用' when a.Findex=11 then '销售' when a.Findex=21 then '退货' end AS PRICETYPE,
      'NONE'AS HANDS,0 AS USEDPOINT,
       b.Famount_Base AS LINETOTAL,
       to_number((SELECT CASE WHEN SUBSTR(B.FBIZKIND,3,'2')<>'12' THEN ''
                     WHEN SUBSTR(B.FBIZKIND,3,'2')='12' AND NVL(TO_NUMBER(FUN_SPLIT_ONE(B.FPROPERTY_VALUE,'/',24)),'0')='0' THEN ''
                     WHEN SUBSTR(B.FBIZKIND,3,'2')='12' AND NVL(FUN_SPLIT_ONE(B.FPROPERTY_VALUE,'/',24),'空')='空' THEN ''
                     WHEN SUBSTR(B.FBIZKIND,3,'2')='12' AND NVL(FUN_SPLIT_ONE(B.FPROPERTY_VALUE,'/',24),'空')<>'空'  AND NVL(TO_NUMBER(FUN_SPLIT_ONE(B.FPROPERTY_VALUE,'/',24)),'0')<>'0'
                     THEN
                         TO_CHAR(ROUND(((B.FAMOUNT_SALE-(CASE
                                                         WHEN NVL(FUN_SPLIT_ONE(B.FPROPERTY_VALUE,'/',52),'空')='空' THEN '0'
                                                         WHEN NVL(FUN_SPLIT_ONE(B.FPROPERTY_VALUE,'/',52),'0')='0' THEN '0'
                                                         ELSE
                                                         TO_CHAR(FUN_SPLIT_ONE(TO_CHAR(B.FPROPERTY_VALUE),'/',52))
                                                         END)-NVL(C.FAMOUNT_SALE,'0'))/FUN_SPLIT_ONE(B.FPROPERTY_VALUE,'/',24)),4))
                     ELSE '0' END AS FPRICE_GOLD
                     FROM BN_BIZ_SA_DE X
                     LEFT JOIN (SELECT distinct A.FPID,A.FRID,A.FAMOUNT_SALE FROM BN_BIZ_PAY_DE A
                                 INNER JOIN BN_BIZ_SPM_MA B ON A.FSID=B.FMID AND B.FINDEX='1270'
                                 WHERE NVL(A.FRID,'0')<>'0') C ON X.FMID=C.FRID
                     WHERE X.FMID=B.FMID)) AS DAYPRICE2,--当日金价（成交金价要减去优惠后的工费）
       to_number((SELECT  CASE WHEN SUBSTR(B.FBIZKIND,3,'2')<>'12' THEN ''
                     WHEN NVL(FUN_SPLIT_ONE(B.FPROPERTY_VALUE,'/',52),'空')='空' THEN '0'
                     WHEN NVL(FUN_SPLIT_ONE(B.FPROPERTY_VALUE,'/',52),'0')='0' THEN '0'
                     ELSE
                     TO_CHAR(FUN_SPLIT_ONE(TO_CHAR(B.FPROPERTY_VALUE),'/',52)-NVL(TO_CHAR(C.FAMOUNT_SALE),'0'))
                       END AS FCOST
                     FROM BN_BIZ_SA_DE X
                     LEFT JOIN (SELECT A.FPID,A.FRID,A.FAMOUNT_SALE FROM BN_BIZ_PAY_DE A
                                 INNER JOIN BN_BIZ_SPM_MA B ON A.FSID=B.FMID AND B.FINDEX='1280'
                                 WHERE NVL(A.FRID,'0')<>'0') C ON X.FMID=C.FRID
                     WHERE  X.FMID=B.FMID)) AS DONEFEE, --成交工费
       0.00 AS FORCASH,g.SPR_ZKJE2 AS DISCOUNT1,0.00 AS MEMWHALEY,0.00 AS MEMCOUPOS,case when Frate_Value is null then b.Famount_Base else b.Famount_Base * (1-b.Frate_Value/100) end AS FEETOTAL,
       0.00 AS STORECOST,0.00 AS COUPONS,case when b.Fprice_Sale is null then b.Famount_Base when i.SPR_ZKJE2 is null then 0 else i.SPR_ZKJE2 end as SYSCOST,0.00 AS MALLSTAMPS,0.00 AS STONENUM,
       0.00 AS AFTERWEIGHT,0.00 AS BEFOREWEIGHT,b.Famount_Sale PRICE,0 AS REMAINQTY,0.00 AS REMAINWEIGHT,
       f.SPR_ZKJE2 AS DISCOUNT,f.SPR_ZKJE2 AS DISCOUNTPRICE,case when a.Findex=11 then to_char(SUBSTR(a.Fde_Code,5,4)) when a.Findex=21 then to_char(SUBSTR(a.Fre_Code,5,4)) end AS LOCCODE,
       case when Frate_Value is null then 0 else b.Frate_Value/100 end AS FEE,case when c.FNAME='内购' then 1 else 0 end AS ISINSIDE,
       to_char(e.fname) AS TYPE1,b.fremark AS MEMO,a.fmid as FMID,a.ftrans_state as ftrans_state,to_char(a.ftrans_time,'yyyymmdd') as ftrans_time,
       to_char(substr(b.fproperty_value,instr(b.fproperty_value,'/',1,5)+1,2)) as ZDL
FROM  BN_BIZ_SA_DE b left join BN_BIZ_SA_MA a on A.FMID=B.FPID
                    left join (select distinct MA_FSID,Fname from zbw_pospay where Fname='内购') c on b.FPID=c.MA_FSID --判断内购
                    left join BN_BIZ_SKU d on b.Fsku_Code=d.FCODE  --取SKU
                    left join BN_BIZ_MRR_DE e on b.frate_id=e.fmid --取开票码大类
                    left join (select Y.FRID,sum(Y.famount_base) as SPR_ZKJE1,sum(Y.famount_sale) as SPR_ZKJE2,sum(Y.famount_discrate) as SPR_ZKJE3
                               from bn_biz_pay_spm Y
                               where Y.famount_sale=Y.famount_discrate and Fname<>'旧料旧货' and Fname<>'定金'
                               group by Y.FRID) f on b.fmid=f.FRID    --取除旧货旧料外折扣
                    left join (select Y.FRID,sum(Y.famount_base) as SPR_ZKJE1,sum(Y.famount_sale) as SPR_ZKJE2,sum(Y.famount_discrate) as SPR_ZKJE3
                               from bn_biz_pay_spm Y
                               where Y.famount_sale=Y.famount_discrate and Fname='旧料旧货'
                               group by Y.FRID) g on b.fmid=g.FRID    --取旧货旧料金额
--                    left join (select Y.FRID,sum(Y.famount_base) as SPR_ZKJE1,sum(Y.famount_sale) as SPR_ZKJE2,sum(Y.famount_discrate) as SPR_ZKJE3
--                               from bn_biz_pay_spm Y
--                               where Y.famount_sale=Y.famount_discrate and Fname in('普通优惠','黄金克减','抹零')
--                               group by Y.FRID) h on b.fmid=h.FRID   --仅直接折扣
                    left join (select Y.FRID,sum(Y.famount_base) as SPR_ZKJE1,sum(Y.famount_sale) as SPR_ZKJE2,sum(Y.famount_discrate) as SPR_ZKJE3
                               from bn_biz_pay_spm Y
                               where Fname in('商场收银','商场收券','现金','银行卡','微信','支付宝','旧料旧货','定金','折旧费','内购')
                               group by Y.FRID) i on b.fmid=i.FRID --取商场金额
WHERE a.Fstate=50 and a.ftrans_state <> 99
union all
--销售（老POS业务类型：折旧费）
SELECT case when a.Findex=11 then to_char(SUBSTR(a.Fde_Code,1,4)) when a.Findex=21 then to_char(SUBSTR(a.Fre_Code,1,4)) end AS SHPCODE,
       a.FCODE AS DOCNUM,b.ffid AS LINENUM,to_char(a.FBIZTIME,'yyyymmdd') AS EXITDATE,'50000002666' AS SKU,'ZJF' AS ITEMCODE,
       to_char(a.Fcreatetime,'yyyymmdd') AS DOCDATE,'NONE' AS ADSCENTRYS,'NONE' AS EMPCODE,'NONE' AS SALEMAKER,'NONE' AS RECHECK,
       'NONE'AS FEETYPE,'NONE' AS RDOCNUM,'NONE' AS CARDID,'NONE' AS CUSPHONE,'NONE' AS CUSCODE,'NONE' AS CUSNAME,'NONE' AS INVOICECODE,
       'NONE' AS ISNEED,'NONE' AS AUDIT1,'NONE'AS INVOICECODE1,'NONE' AS RETURNTYPE,'NONE' AS REPAIRADDRESS,to_char(a.Fupdatetime,'yyyymmdd') AS LASTDATE,
       case when a.Findex=11 then '0' when a.Findex=21 then '1' end AS SOURCETYPE,
       a.Fscode AS SOURCENUM,'NONE' AS AGRDELDATE,'NONE' AS REMAINNAME,a.Foperatorid AS MAKER,0 AS POINT1,0.00 AS COST1,0.00 AS GOLDNUM,0 AS USEPOINT,
       0.00 AS USEBALANCE,0 AS QTY1,0.00 AS EARNEST,0.00 AS BALANCE,0 AS ADDPOINT,0.00 AS WEIGHT,b.Famount_Sale AS MARKEDPRICE,'费用' AS PRICETYPE,
       'NONE'AS HANDS,0 AS USEDPOINT,b.Famount_Sale AS LINETOTAL,0.00 AS DAYPRICE2,0.00 AS DONEFEE,0.00 AS FORCASH,0.00 AS DISCOUNT1,0.00 AS MEMWHALEY,
       0.00 AS MEMCOUPOS,0.00 AS FEETOTAL,0.00 AS STORECOST,0.00 AS COUPONS,b.Famount_Sale AS SYSCOST,0.00 AS MALLSTAMPS,0.00 AS STONENUM,0.00 AS AFTERWEIGHT,
       0.00 AS BEFOREWEIGHT,0.00 AS PRICE,0 AS REMAINQTY,0.00 AS REMAINWEIGHT,0.00 AS DISCOUNT,0.00 AS DISCOUNTPRICE,to_char('') AS LOCCODE,
       0 AS FEE,case when b.FNAME='内购' then 1 else 0 end AS ISINSIDE,'NONE' AS TYPE1,b.fremark AS MEMO,a.fmid as FMID,1 as ftrans_state,to_char('','yyyymmdd') as ftrans_time,
       '费用' as ZDL
FROM (select b.ffid,b.MA_FSID,b.FNAME,b.Fremark,sum(b.Famount_Sale) as Famount_Sale from zbw_pospay b where Fname='折旧费' group by b.ffid,b.MA_FSID,b.FNAME,b.Fremark) b
             left join BN_BIZ_SA_MA a on a.fmid=b.MA_FSID
WHERE a.Fstate=50 and a.ftrans_state <> 99
union all
--select b.* from BN_BIZ_SA_MA a left join zbw_pospay b on a.fmid=b.MA_FSID where b.FNAME='折旧费'
--销售（老POS业务类型：旧货、旧料）
SELECT case when a.Findex=11 then to_char(SUBSTR(a.Fde_Code,1,4)) when a.Findex=21 then to_char(SUBSTR(a.Fre_Code,1,4)) end AS SHPCODE,
       a.FCODE AS DOCNUM,b.ffid AS LINENUM,to_char(a.FBIZTIME,'yyyymmdd') AS EXITDATE,to_char(c.FSPU_ID) AS SKU,
       to_char(b.RE_FCODE) AS ITEMCODE,to_char(a.Fcreatetime,'yyyymmdd') AS DOCDATE,'NONE' AS ADSCENTRYS,'NONE' AS EMPCODE,'NONE' AS SALEMAKER,'NONE' AS RECHECK,
      'NONE'AS FEETYPE,'NONE' AS RDOCNUM,'NONE' AS CARDID,'NONE' AS CUSPHONE,'NONE' AS CUSCODE,'NONE' AS CUSNAME,'NONE' AS INVOICECODE,'NONE' AS ISNEED,'NONE' AS AUDIT1,
      'NONE'AS INVOICECODE1,'NONE' AS RETURNTYPE,'NONE' AS REPAIRADDRESS,to_char(a.Fupdatetime,'yyyymmdd') AS LASTDATE,
       case when a.Findex=11 then '0' when a.Findex=21 then '1' end AS SOURCETYPE,
       a.Fscode AS SOURCENUM,'NONE' AS AGRDELDATE,'NONE' AS REMAINNAME,a.Foperatorid AS MAKER,0 AS POINT1,0.00 AS COST1,0.00 AS GOLDNUM,0 AS USEPOINT,0.00 AS USEBALANCE,-1 AS QTY1,
       0.00 AS EARNEST,0.00 AS BALANCE,0 AS ADDPOINT,0 AS WEIGHT,0-b.RE_Famount_Base AS MARKEDPRICE,
       case when b.RE_FINDEX='10' then '旧料' when b.RE_FINDEX='20' then '旧货' when b.RE_FINDEX='21' then '旧料' end AS PRICETYPE,
      'NONE'AS HANDS,0 AS USEDPOINT,
       0-b.RE_Famount_Base AS LINETOTAL,0.00 AS DAYPRICE2,0.00 AS DONEFEE,0.00 AS FORCASH,0.00 AS DISCOUNT1,0.00 AS MEMWHALEY,0.00 AS MEMCOUPOS,0.00 AS FEETOTAL,
       0.00 AS STORECOST,0.00 AS COUPONS,0-b.Famount_sale AS SYSCOST,0.00 AS MALLSTAMPS,0.00 AS STONENUM,0.00 AS AFTERWEIGHT,0.00 AS BEFOREWEIGHT,0.00 AS PRICE,0 AS REMAINQTY,0.00 AS REMAINWEIGHT,
       0.00 AS DISCOUNT,0.00 AS DISCOUNTPRICE,'0001' AS LOCCODE,
       0 AS FEE,case when b.FNAME='内购' then 1 else 0 end AS ISINSIDE,'NONE' AS TYPE1,b.fremark AS MEMO,a.fmid as FMID,1 as ftrans_state,to_char('','yyyymmdd') as ftrans_time,
       case when b.RE_FINDEX='10' then '旧料' when b.RE_FINDEX='20' then '旧货' when b.RE_FINDEX='21' then '旧料' end as ZDL
FROM ZBW_POSRETRIEVE b left join BN_BIZ_SA_MA a on a.fmid=b.MA_FSID
                       left join bn_biz_sku c on c.FCODE=b.RE_FCODE
WHERE a.Fstate=50 and a.ftrans_state <> 99 and b.FNAME='旧料旧货'
/

