create view ZBW_CHECK_POS_SALES_001 as
  select to_char(a.EXITDATE) as 日期,to_char(a.SHPCODE) as 门店,to_char(a.DOCNUM) as 小票号
    from ZBW_POSSALES_NEW a
    where
          --to_char(to_date(a.EXITDATE,'yyyymmdd'),'yyyymm')=to_char(sysdate,'yyyymm') and a.EXITDATE<>to_char(sysdate,'yyyymmdd') and
          --to_char(to_date(a.EXITDATE,'yyyymmdd'),'yyyymmdd')='20181029' and
          a.FATT_MD not in('电商店-B2B','电商店-B2C') and to_char(a.LOCCODE)<>'0009' and a.ZDL not in('旧料','其他') and
          a.PRICETYPE in('销售','套装','退货','截金','旧货') and a.ISINSIDE<>1
/

