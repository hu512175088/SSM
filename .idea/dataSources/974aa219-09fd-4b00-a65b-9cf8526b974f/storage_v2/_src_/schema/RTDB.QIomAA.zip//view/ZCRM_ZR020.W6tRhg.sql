create view ZCRM_ZR020 as
  SELECT
a."card_num" as 卡号,
substr(b.EXITDATE,1,4)||'-'||substr(b.EXITDATE,5,2)||'-'||substr(b.EXITDATE,7,2) as 消费时间,
a."card_giving_time" as 开卡时间,
a."store_code" as 门店代码,
(SUBSTR(c.FA003_NAME,0,2)||c.FA002_NAME) AS 区域,
c."FA030_NAME" AS 区经,
"TO_CHAR"(a."card_giving_time",'yyyy-mm-dd') as 开卡年月,
"TO_CHAR"(a."card_giving_time",'mm-dd') as 开卡月
from crm_tab_gic_member a 
LEFT JOIN ZBW_POSSALES_CRM_MAIN  b on a."card_num" = b.cardno
LEFT JOIN BN_SYS_ORG_INFO c on a."store_code" = c."FCODE"
where "card_num" <> '-1' and  --"TO_CHAR"(a."card_giving_time",'yyyy-mm')
     --"TO_CHAR"(b."ReceiptsTime",'yyyy-mm') = '2018-09' 
       a."store_code" <> 'saler_E3' and a."store_code" <> '5274'  and a."store_code" <> '5271'
       and ((SUBSTR(c.FA003_NAME,0,2)||c.FA002_NAME) LIKE '加盟%' OR (SUBSTR(c.FA003_NAME,0,2)||c.FA002_NAME) LIKE '直营%')
       and a."store_code" <> '1111'
/

