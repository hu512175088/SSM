create view ZCRM_R002 as
  SELECT 
a."card_num" as 会员手机号,
a."grade_name" as 等级,
"TO_CHAR"(a."card_giving_time",'yyyy-mm') as 开卡年月,
"TO_CHAR"(c."last_cost_time",'yyyy-mm') as 最后消费年月,
a."card_giving_time" as 开卡日期,
c."last_cost_time" as 最后消费日期
from CRM_TAB_GIC_MEMBER a
LEFT JOIN CRM_TAB_GIC_MEMBER_INFO c on a."member_id" = c."member_id"
where a."card_num" <> -1 and "grade_name" <> '特殊卡'
/

