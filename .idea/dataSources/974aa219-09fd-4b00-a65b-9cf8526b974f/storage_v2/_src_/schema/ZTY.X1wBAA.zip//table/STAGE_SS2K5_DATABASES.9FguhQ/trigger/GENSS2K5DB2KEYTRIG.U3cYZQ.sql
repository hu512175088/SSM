create trigger GENSS2K5DB2KEYTRIG
  before insert
  on STAGE_SS2K5_DATABASES
  for each row
  BEGIN IF :new.dbid_gen IS NULL THEN :new.dbid_gen := MD_META.get_next_id;
END IF;
END Genss2k5Db2KeyTrig;
/

