create trigger GENSS2K5SQLMODTRIG
  before insert
  on STAGE_SS2K5_SQL_MODULES
  for each row
  BEGIN IF :new.OBJID_GEN IS NULL THEN :new.OBJID_GEN := MD_META.get_next_id;
END IF;
END Genss2k5SqlModTrig;
/

