create trigger GENSS2K5IDENTCOLRIG
  before insert
  on STAGE_SS2K5_IDENTITY_COLUMNS
  for each row
  BEGIN IF :new.OBJECT_ID_gen IS NULL THEN :new.OBJECT_ID_gen := MD_META.get_next_id;
END IF;
END Genss2k5IdentColTrig;
/

