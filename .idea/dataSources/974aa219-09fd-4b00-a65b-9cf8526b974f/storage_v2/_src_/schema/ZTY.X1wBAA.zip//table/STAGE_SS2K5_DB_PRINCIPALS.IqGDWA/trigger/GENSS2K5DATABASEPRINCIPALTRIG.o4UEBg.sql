create trigger GENSS2K5DATABASEPRINCIPALTRIG
  before insert
  on STAGE_SS2K5_DB_PRINCIPALS
  for each row
  BEGIN IF :new.prinid_gen IS NULL THEN :new.prinid_gen := MD_META.get_next_id;
END IF;
END Genss2k5DatabasePrincipalTrig;
/

