create trigger GENINDEXKEYTRIG
  before insert
  on STAGE_SYB12_SYSINDEXES
  for each row
  BEGIN
					  IF :new.indid_gen is null THEN
					     :new.indid_gen := MD_META.get_next_id;
					  END IF;
                    END GenIndexKeyTrig;
/

