create trigger GENDBKEYTRIG
  before insert
  on STAGE_SYB12_SYSDATABASES
  for each row
  BEGIN
					  IF :new.dbid_gen is null THEN
					     :new.dbid_gen := MD_META.get_next_id;
					  END IF;
					END GenDbKeyTrig;
/

