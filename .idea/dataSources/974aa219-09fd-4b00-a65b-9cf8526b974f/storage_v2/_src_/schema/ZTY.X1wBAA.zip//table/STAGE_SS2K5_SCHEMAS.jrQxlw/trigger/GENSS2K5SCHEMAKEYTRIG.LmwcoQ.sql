create trigger GENSS2K5SCHEMAKEYTRIG
  before insert
  on STAGE_SS2K5_SCHEMAS
  for each row
  BEGIN IF :new.suid_gen IS NULL THEN :new.suid_gen := MD_META.get_next_id;
END IF;
END Genss2k5SchemaKeyTrig;
/

