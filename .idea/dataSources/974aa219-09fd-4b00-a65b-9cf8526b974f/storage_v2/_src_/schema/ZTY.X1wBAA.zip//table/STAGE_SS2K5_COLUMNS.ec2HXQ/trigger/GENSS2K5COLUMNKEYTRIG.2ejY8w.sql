create trigger GENSS2K5COLUMNKEYTRIG
  before insert
  on STAGE_SS2K5_COLUMNS
  for each row
  BEGIN IF :new.colid_gen IS NULL THEN :new.colid_gen := MD_META.get_next_id;
END IF;
END Genss2k5ColumnKeyTrig;
/

