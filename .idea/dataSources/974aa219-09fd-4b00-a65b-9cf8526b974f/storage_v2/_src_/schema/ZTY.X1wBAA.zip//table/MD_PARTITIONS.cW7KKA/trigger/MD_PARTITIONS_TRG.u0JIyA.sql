create trigger MD_PARTITIONS_TRG
  before insert or update
  on MD_PARTITIONS
  for each row
  BEGIN
  if inserting and :new.id is null then
        :new.id := MD_META.get_next_id;
    end if;
END;
/

