create trigger GENSCHEMAKEYTRIG
  before insert
  on STAGE_SYB12_SYSUSERS
  for each row
  BEGIN
					  IF :new.suid_gen is null THEN
					     :new.suid_gen := MD_META.get_next_id;
					  END IF;
					END GenSchemaKeyTrig;
/

