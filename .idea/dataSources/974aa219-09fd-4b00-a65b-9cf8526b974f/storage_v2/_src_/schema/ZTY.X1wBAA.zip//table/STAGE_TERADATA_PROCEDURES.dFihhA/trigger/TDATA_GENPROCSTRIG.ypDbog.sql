create trigger TDATA_GENPROCSTRIG
  before insert
  on STAGE_TERADATA_PROCEDURES
  for each row
  BEGIN
                                  IF :new.MDID IS NULL OR :new.MDID=0 THEN
                                     :new.MDID := MD_META.get_next_id;
                                  END IF;
                                END TDATA_GENPROCSTRIG;
/

