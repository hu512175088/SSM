create trigger GENSS2K5INDEXTRIG
  before insert
  on STAGE_SS2K5_INDEXES
  for each row
  BEGIN IF :new.object_id_gen IS NULL THEN :new.object_id_gen := MD_META.get_next_id;
END IF;
END Genss2k5IndexTrig;
/

