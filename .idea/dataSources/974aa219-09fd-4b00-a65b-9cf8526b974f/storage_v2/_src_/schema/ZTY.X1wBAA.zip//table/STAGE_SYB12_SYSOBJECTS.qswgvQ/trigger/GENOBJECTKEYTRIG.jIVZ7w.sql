create trigger GENOBJECTKEYTRIG
  before insert
  on STAGE_SYB12_SYSOBJECTS
  for each row
  BEGIN
					  IF :new.objid_gen is null THEN
					     :new.objid_gen := MD_META.get_next_id;
					  END IF;
					END GenObjectKeyTrig;
/

