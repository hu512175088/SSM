create trigger GENCOLUMNKEYTRIG
  before insert
  on STAGE_SYB12_SYSCOLUMNS
  for each row
  BEGIN
					  IF :new.colid_gen is null THEN
					     :new.colid_gen := MD_META.get_next_id;
					  END IF;
					END GenColumnKeyTrig;
/

