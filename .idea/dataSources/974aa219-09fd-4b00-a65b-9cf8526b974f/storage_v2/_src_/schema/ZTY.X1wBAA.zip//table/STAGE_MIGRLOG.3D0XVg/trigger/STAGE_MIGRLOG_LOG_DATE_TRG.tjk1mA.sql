create trigger STAGE_MIGRLOG_LOG_DATE_TRG
  before insert or update
  on STAGE_MIGRLOG
  for each row
  BEGIN
  if inserting and :new.log_date is null then
        :new.log_date := systimestamp;
    end if;
END;
/

