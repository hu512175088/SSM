create trigger GENSS2K5DEFCONSTTRIG
  before insert
  on STAGE_SS2K5_DT_CONSTRAINTS
  for each row
  BEGIN IF :new.OBJID_GEN IS NULL THEN :new.OBJID_GEN := MD_META.get_next_id;
END IF;
END Genss2k5DefConstTrig;
/

